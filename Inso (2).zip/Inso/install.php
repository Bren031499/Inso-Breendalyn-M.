<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);


$host = 'localhost';
$user = 'root';
$pass = '';
$database = 'ecommerce_db';


$conn = mysqli_connect($host, $user, $pass, $database);


if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "<h1>Database Installation for BeverageHub</h1>";


$tables = ['order_items', 'orders', 'products', 'brands', 'clients', 'admins', 'order_statuses', 'payment_modes'];

foreach($tables as $table) {
    mysqli_query($conn, "DROP TABLE IF EXISTS $table");
    echo "✓ Dropped table: $table (if existed)<br>";
}

echo "<h2>Creating tables...</h2>";


$sql = "CREATE TABLE order_statuses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    status_name VARCHAR(50) NOT NULL UNIQUE
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: order_statuses<br>";
} else {
    echo "✗ Error creating order_statuses: " . mysqli_error($conn) . "<br>";
}


$sql = "CREATE TABLE payment_modes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mode_name VARCHAR(100) NOT NULL
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: payment_modes<br>";
} else {
    echo "✗ Error creating payment_modes: " . mysqli_error($conn) . "<br>";
}

$sql = "CREATE TABLE brands (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brand_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: brands<br>";
} else {
    echo "✗ Error creating brands: " . mysqli_error($conn) . "<br>";
}

$sql = "CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(200) NOT NULL,
    brand_id INT,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    description TEXT,
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE SET NULL
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: products<br>";
} else {
    echo "✗ Error creating products: " . mysqli_error($conn) . "<br>";
}

$sql = "CREATE TABLE clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: clients<br>";
} else {
    echo "✗ Error creating clients: " . mysqli_error($conn) . "<br>";
}


$sql = "CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: admins<br>";
} else {
    echo "✗ Error creating admins: " . mysqli_error($conn) . "<br>";
}


$sql = "CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status_id INT DEFAULT 1,
    payment_mode_id INT,
    shipping_address TEXT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (status_id) REFERENCES order_statuses(id),
    FOREIGN KEY (payment_mode_id) REFERENCES payment_modes(id)
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: orders<br>";
} else {
    echo "✗ Error creating orders: " . mysqli_error($conn) . "<br>";
}

$sql = "CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
)";
if(mysqli_query($conn, $sql)) {
    echo "✓ Created table: order_items<br>";
} else {
    echo "✗ Error creating order_items: " . mysqli_error($conn) . "<br>";
}

echo "<h2>Inserting default data...</h2>";

mysqli_query($conn, "INSERT INTO order_statuses (status_name) VALUES 
    ('Pending'), ('Processing'), ('Shipped'), ('Delivered'), ('Cancelled')");
echo "✓ Inserted order statuses<br>";

mysqli_query($conn, "INSERT INTO payment_modes (mode_name) VALUES 
    ('Cash on Delivery'), ('Credit Card'), ('GCash'), ('Bank Transfer')");
echo "✓ Inserted payment modes<br>";


$hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
mysqli_query($conn, "INSERT INTO admins (username, email, password) VALUES 
    ('admin', 'admin@example.com', '$hashed_password')");
echo "✓ Inserted admin user (admin@example.com / admin123)<br>";


mysqli_query($conn, "INSERT INTO brands (brand_name, description) VALUES 
    ('Coca-Cola', 'Carbonated soft drinks'),
    ('Pepsi', 'Soft drinks and beverages'),
    ('Nestle', 'Milk and dairy products'),
    ('Starbucks', 'Coffee products')");
echo "✓ Inserted sample brands<br>";


mysqli_query($conn, "INSERT INTO products (product_name, brand_id, price, stock_quantity, description) VALUES 
    ('Coca-Cola Classic', 1, 59.00, 100, 'Original refreshing taste'),
    ('Pepsi Cola', 2, 55.00, 100, 'Crisp and refreshing'),
    ('Nestle Fresh Milk', 3, 55.00, 50, 'Fresh full cream milk'),
    ('Starbucks Frappuccino', 4, 120.00, 50, 'Coffee blended beverage')");
echo "✓ Inserted sample products<br>";


mysqli_query($conn, "INSERT INTO clients (fullname, email, phone, address, password) VALUES 
    ('John Doe', 'john@example.com', '09123456789', 'Manila, Philippines', 'password123')");
echo "✓ Inserted sample customer<br>";

echo "<h2 style='color: green;'>✅ Database setup complete!</h2>";
echo "<div style='background: #dbeafe; padding: 20px; border-radius: 10px; margin: 20px 0;'>";
echo "<h3>Login Credentials:</h3>";
echo "<p><strong>Admin Login:</strong><br>";
echo "Email: admin@example.com<br>";
echo "Password: admin123</p>";
echo "<p><strong>Customer Login:</strong><br>";
echo "Email: john@example.com<br>";
echo "Password: password123</p>";
echo "</div>";
echo "<a href='admin/login.php' style='background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Go to Admin Login →</a>";
echo "<a href='login.php' style='background: #8b5cf6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Customer Login →</a>";

mysqli_close($conn);
?>