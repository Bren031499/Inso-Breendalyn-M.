<?php
session_start();
require_once '../config/db_connect.php';

$pid = intval($_GET['id']);
$prod = mysqli_query($conn, "SELECT p.*, b.name as brand_name FROM products p LEFT JOIN brands b ON p.brand_id=b.id WHERE p.id=$pid");
$product = mysqli_fetch_assoc($prod);

if(!$product) {
    header("Location: home.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - UrbanCart</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="home.php" class="text-2xl font-bold text-blue-600">🛒 UrbanCart</a>
            <div>
                <?php if(isset($_SESSION['client_id'])): ?>
                    <span class="mr-4">Hi, <?php echo htmlspecialchars($_SESSION['client_name']); ?></span>
                    <a href="cart.php" class="mr-3 text-gray-700">Cart</a>
                    <a href="logout.php" class="text-red-500">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="bg-blue-500 text-white px-4 py-2 rounded">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <div class="container mx-auto p-6">
        <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div class="md:flex">
                <div class="md:w-1/2">
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                         class="w-full h-96 object-cover">
                </div>
                <div class="md:w-1/2 p-6">
                    <h1 class="text-3xl font-bold mb-2"><?php echo htmlspecialchars($product['name']); ?></h1>
                    <p class="text-gray-600 mb-2">Brand: <?php echo htmlspecialchars($product['brand_name']); ?></p>
                    <p class="text-gray-600 mb-4">Stock: <?php echo $product['stock']; ?> units</p>
                    <p class="text-4xl font-bold text-blue-600 mb-4">$<?php echo number_format($product['price'], 2); ?></p>
                    <p class="text-gray-700 mb-6"><?php echo htmlspecialchars($product['description']); ?></p>
                    
                    <?php if(isset($_SESSION['client_id'])): ?>
                        <form method="GET" action="cart.php" class="flex gap-3">
                            <input type="hidden" name="add" value="<?php echo $product['id']; ?>">
                            <input type="number" name="qty" value="1" min="1" max="<?php echo $product['stock']; ?>" 
                                   class="border border-gray-300 p-2 rounded w-20">
                            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">
                                Add to Cart
                            </button>
                        </form>
                    <?php else: ?>
                        <p class="text-red-500">Please <a href="login.php" class="underline">login</a> to add items to cart.</p>
                    <?php endif; ?>
                    
                    <div class="mt-6">
                        <a href="home.php" class="text-blue-500 hover:underline">← Back to Shop</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>