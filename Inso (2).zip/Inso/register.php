<?php
session_start();

$error = '';
$success = '';


if (!isset($_SESSION['users'])) {
    $_SESSION['users'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    
    if (empty($fullname) || empty($email) || empty($phone) || empty($address) || empty($password)) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        
        $email_exists = false;
        foreach ($_SESSION['users'] as $user) {
            if ($user['email'] === $email) {
                $email_exists = true;
                break;
            }
        }
        
        if ($email_exists) {
            $error = "Email already registered. Please use a different email or <a href='login.php'>login</a>.";
        } else {
            
            $new_user = [
                'user_id' => count($_SESSION['users']) + 1,
                'fullname' => $fullname,
                'email' => $email,
                'phone' => $phone,
                'address' => $address,
                'password' => $password, 
                'registered_at' => date('Y-m-d H:i:s')
            ];
            
            $_SESSION['users'][] = $new_user;
            $_SESSION['register_success'] = "Registration successful! Please login with your credentials.";
            
            header("Location: login.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - EARTHEN STYLE</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        h1, h2, .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: linear-gradient(135deg, #2c1810 0%, #3d2a1f 50%, #5c3a2e 100%);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }
        
        .btn-register {
            background: linear-gradient(135deg, #A0522D 0%, #8B4513 100%);
            transition: all 0.3s ease;
        }
        
        .btn-register:hover {
            background: linear-gradient(135deg, #8B4513 0%, #6B3410 100%);
            transform: scale(1.02);
            box-shadow: 0 10px 25px -5px rgba(160, 82, 45, 0.4);
        }
        
        .register-card {
            background: rgba(255, 251, 245, 0.98);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(160, 82, 45, 0.2);
        }
        
        .animate-float {
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
        }
        
        .leaf-bg {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            opacity: 0.05;
            pointer-events: none;
        }
        
        input:focus, textarea:focus {
            border-color: #A0522D !important;
            ring-color: #A0522D !important;
            box-shadow: 0 0 0 3px rgba(160, 82, 45, 0.2) !important;
            outline: none;
        }
        
        .input-field {
            transition: all 0.3s ease;
        }
        
        .input-field:focus {
            border-color: #A0522D;
            box-shadow: 0 0 0 3px rgba(160, 82, 45, 0.1);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 relative">
    <div class="leaf-bg text-9xl text-center text-white">🌿🍂🌾🍃</div>
    
    <div class="register-card rounded-2xl shadow-2xl p-8 w-full max-w-md fade-in relative z-10">
        <div class="text-center mb-6">
            <div class="text-5xl mb-3 animate-float">🌿</div>
            <a href="home.php" class="text-3xl font-bold tracking-tight">
                <span class="serif text-gray-800">EARTHEN</span>
                <span class="serif text-[#A0522D]"> STYLE</span>
            </a>
            <p class="text-gray-600 mt-2">Create your account</p>
            <p class="text-xs text-gray-500 mt-1">Join the Earth-inspired community</p>
        </div>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-start">
                <i class="fas fa-exclamation-circle mt-0.5 mr-2"></i>
                <span><?php echo $error; ?></span>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="registerForm">
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-2 text-sm">
                    <i class="fas fa-user mr-2 text-[#A0522D]"></i>Full Name
                </label>
                <input type="text" name="fullname" required 
                       class="input-field w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none transition"
                       placeholder="Juan Dela Cruz">
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-2 text-sm">
                    <i class="fas fa-envelope mr-2 text-[#A0522D]"></i>Email Address
                </label>
                <input type="email" name="email" required 
                       class="input-field w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none transition"
                       placeholder="you@example.com">
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-2 text-sm">
                    <i class="fas fa-phone mr-2 text-[#A0522D]"></i>Phone Number
                </label>
                <input type="tel" name="phone" required 
                       class="input-field w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none transition"
                       placeholder="0912 345 6789">
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-2 text-sm">
                    <i class="fas fa-map-marker-alt mr-2 text-[#A0522D]"></i>Address
                </label>
                <textarea name="address" rows="2" required 
                          class="input-field w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none transition"
                          placeholder="Your complete address"></textarea>
            </div>
            <div class="mb-3">
                <label class="block text-gray-700 font-semibold mb-2 text-sm">
                    <i class="fas fa-lock mr-2 text-[#A0522D]"></i>Password
                </label>
                <input type="password" name="password" required 
                       class="input-field w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none transition"
                       placeholder="Minimum 6 characters">
                <p class="text-xs text-gray-500 mt-1">Password must be at least 6 characters</p>
            </div>
            <div class="mb-5">
                <label class="block text-gray-700 font-semibold mb-2 text-sm">
                    <i class="fas fa-lock mr-2 text-[#A0522D]"></i>Confirm Password
                </label>
                <input type="password" name="confirm_password" required 
                       class="input-field w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none transition"
                       placeholder="Confirm your password">
            </div>
            <button type="submit" 
                    class="btn-register w-full text-white font-bold py-3 rounded-lg transition flex items-center justify-center gap-2 shadow-md hover:shadow-xl">
                <i class="fas fa-leaf"></i>
                Create Account
            </button>
        </form>
        
        <div class="text-center mt-6">
            <p class="text-gray-600">
                Already have an account? 
                <a href="login.php" class="text-[#A0522D] hover:underline font-semibold transition">
                    <i class="fas fa-sign-in-alt mr-1"></i>Sign In
                </a>
            </p>
        </div>
        
        <div class="mt-6 text-center">
            <a href="home.php" class="text-gray-500 hover:text-[#A0522D] text-sm transition flex items-center justify-center gap-1">
                <i class="fas fa-arrow-left"></i> Back to Store
            </a>
        </div>
    </div>

    <script>
        
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.querySelector('input[name="password"]').value;
            const confirm = document.querySelector('input[name="confirm_password"]').value;
            
            if (password !== confirm) {
                e.preventDefault();
                alert('Passwords do not match!');
            } else if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long!');
            }
        });
    </script>
</body>
</html>