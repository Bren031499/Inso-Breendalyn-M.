// ==================== BEVERAGEHUB - COMPLETE JAVASCRIPT ====================

// Wait for DOM to fully load
document.addEventListener('DOMContentLoaded', function() {
    
    // ==================== CART FUNCTIONALITY ====================
    
    // Update cart quantity buttons
    function initCartButtons() {
        const updateButtons = document.querySelectorAll('.update-cart-btn');
        const removeButtons = document.querySelectorAll('.remove-item-btn');
        const quantityInputs = document.querySelectorAll('.cart-quantity');
        
        // Update quantity when input changes
        quantityInputs.forEach(input => {
            input.addEventListener('change', function() {
                const cartId = this.dataset.cartId;
                const newQuantity = this.value;
                updateCartItem(cartId, newQuantity);
            });
        });
        
        // Remove item from cart
        removeButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const cartId = this.dataset.cartId;
                if (confirm('Remove this item from your cart?')) {
                    removeCartItem(cartId);
                }
            });
        });
    }
    
    // Update cart item via AJAX
    function updateCartItem(cartId, quantity) {
        fetch('update_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `cart_id=${cartId}&quantity=${quantity}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload(); // Refresh to show updated cart
            } else {
                showNotification('Error updating cart', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Failed to update cart', 'error');
        });
    }
    
    // Remove cart item via AJAX
    function removeCartItem(cartId) {
        fetch('remove_from_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `cart_id=${cartId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showNotification('Error removing item', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Failed to remove item', 'error');
        });
    }
    
    // ==================== ADD TO CART WITH ANIMATION ====================
    
    // Add to cart functionality with animation
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Don't prevent default if it's a form submission
            if (this.type === 'submit') {
                // Show loading state
                const originalText = this.innerHTML;
                this.innerHTML = '⏳ Adding...';
                this.disabled = true;
                
                // Reset button after 2 seconds (form will submit anyway)
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 2000);
                
                // Show floating notification
                showFloatingNotification('Added to cart! 🛒');
            }
        });
    });
    
    // Floating notification
    function showFloatingNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'floating-notification';
        notification.innerHTML = `
            <div class="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-bounce">
                ✅ ${message}
            </div>
        `;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    }
    
    // ==================== SHOW/HIDE CART SIDEBAR ====================
    
    // Toggle cart sidebar (if you want to add one)
    const cartIcon = document.getElementById('cartIcon');
    const cartSidebar = document.getElementById('cartSidebar');
    const cartOverlay = document.getElementById('cartOverlay');
    
    if (cartIcon && cartSidebar && cartOverlay) {
        cartIcon.addEventListener('click', openCart);
        
        function openCart() {
            cartSidebar.classList.add('open');
            cartOverlay.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
        
        function closeCart() {
            cartSidebar.classList.remove('open');
            cartOverlay.style.display = 'none';
            document.body.style.overflow = '';
        }
        
        document.querySelector('.close-cart')?.addEventListener('click', closeCart);
        cartOverlay.addEventListener('click', closeCart);
    }
    
    // ==================== FORM VALIDATION ====================
    
    // Login form validation
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email');
            const password = document.getElementById('password');
            let errors = [];
            
            if (!email.value) {
                errors.push('Email is required');
                showFieldError(email, 'Email is required');
            } else if (!isValidEmail(email.value)) {
                errors.push('Please enter a valid email address');
                showFieldError(email, 'Invalid email format');
            } else {
                clearFieldError(email);
            }
            
            if (!password.value) {
                errors.push('Password is required');
                showFieldError(password, 'Password is required');
            } else if (password.value.length < 4) {
                errors.push('Password must be at least 4 characters');
                showFieldError(password, 'Minimum 4 characters');
            } else {
                clearFieldError(password);
            }
            
            if (errors.length > 0) {
                e.preventDefault();
                showNotification(errors[0], 'error');
            }
        });
    }
    
    // Register form validation
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const fullname = document.getElementById('fullname');
            const email = document.getElementById('email');
            const password = document.getElementById('password');
            let errors = [];
            
            if (!fullname.value) {
                errors.push('Full name is required');
                showFieldError(fullname, 'Name is required');
            } else if (fullname.value.length < 2) {
                errors.push('Name must be at least 2 characters');
                showFieldError(fullname, 'Too short');
            } else {
                clearFieldError(fullname);
            }
            
            if (!email.value) {
                errors.push('Email is required');
                showFieldError(email, 'Email is required');
            } else if (!isValidEmail(email.value)) {
                errors.push('Please enter a valid email address');
                showFieldError(email, 'Invalid email');
            } else {
                clearFieldError(email);
            }
            
            if (!password.value) {
                errors.push('Password is required');
                showFieldError(password, 'Password required');
            } else if (password.value.length < 4) {
                errors.push('Password must be at least 4 characters');
                showFieldError(password, 'Minimum 4 chars');
            } else {
                clearFieldError(password);
            }
            
            if (errors.length > 0) {
                e.preventDefault();
                showNotification(errors[0], 'error');
            }
        });
    }
    
    // Helper functions for form validation
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showFieldError(field, message) {
        field.classList.add('border-red-500');
        let errorSpan = field.parentElement.querySelector('.field-error');
        if (!errorSpan) {
            errorSpan = document.createElement('span');
            errorSpan.className = 'field-error text-red-500 text-xs mt-1 block';
            field.parentElement.appendChild(errorSpan);
        }
        errorSpan.textContent = message;
    }
    
    function clearFieldError(field) {
        field.classList.remove('border-red-500');
        const errorSpan = field.parentElement.querySelector('.field-error');
        if (errorSpan) {
            errorSpan.remove();
        }
    }
    
    // ==================== NOTIFICATION SYSTEM ====================
    
    function showNotification(message, type = 'success') {
        const colors = {
            success: 'bg-green-500',
            error: 'bg-red-500',
            info: 'bg-blue-500',
            warning: 'bg-yellow-500'
        };
        
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-all duration-300 transform translate-x-full`;
        notification.innerHTML = `
            <div class="flex items-center gap-3">
                <span>${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
                        <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-4 hover:opacity-75">×</button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.classList.remove('translate-x-full');
        }, 100);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
    
    // ==================== SEARCH PRODUCTS (Live Search) ====================
    
    const searchInput = document.getElementById('searchProducts');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const productCards = document.querySelectorAll('.product-card');
            
            productCards.forEach(card => {
                const productName = card.querySelector('.product-name')?.textContent.toLowerCase() || '';
                const productFlavor = card.querySelector('.product-flavor')?.textContent.toLowerCase() || '';
                
                if (productName.includes(searchTerm) || productFlavor.includes(searchTerm)) {
                    card.style.display = 'block';
                    card.style.animation = 'fadeIn 0.3s ease';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // ==================== FILTER PRODUCTS BY PRICE ====================
    
    const priceFilter = document.getElementById('priceFilter');
    if (priceFilter) {
        priceFilter.addEventListener('change', function() {
            const maxPrice = parseFloat(this.value);
            const productCards = document.querySelectorAll('.product-card');
            
            productCards.forEach(card => {
                const priceText = card.querySelector('.product-price')?.textContent || '₱0';
                const price = parseFloat(priceText.replace('₱', ''));
                
                if (price <= maxPrice) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // ==================== QUANTITY COUNTERS ====================
    
    function initQuantityCounters() {
        const minusButtons = document.querySelectorAll('.qty-minus');
        const plusButtons = document.querySelectorAll('.qty-plus');
        
        minusButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('.qty-input');
                let value = parseInt(input.value);
                if (value > 1) {
                    input.value = value - 1;
                    input.dispatchEvent(new Event('change'));
                }
            });
        });
        
        plusButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('.qty-input');
                let value = parseInt(input.value);
                input.value = value + 1;
                input.dispatchEvent(new Event('change'));
            });
        });
    }
    
    // ==================== CHECKOUT PROCESSING ====================
    
    const checkoutBtn = document.getElementById('checkoutBtn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show processing modal
            showProcessingModal();
            
            // Simulate processing
            setTimeout(() => {
                const total = document.querySelector('.cart-total-value')?.textContent || '₱0';
                showNotification(`Order placed successfully! Total: ${total}`, 'success');
                closeProcessingModal();
                
                // Optional: redirect to order confirmation
                setTimeout(() => {
                    window.location.href = 'order_confirmation.php';
                }, 1500);
            }, 2000);
        });
    }
    
    function showProcessingModal() {
        const modal = document.createElement('div');
        modal.id = 'processingModal';
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-2xl p-8 text-center">
                <div class="text-5xl mb-4 animate-spin">⏳</div>
                <h3 class="text-xl font-bold mb-2">Processing Order...</h3>
                <p class="text-gray-600">Please wait while we confirm your order</p>
                <div class="mt-4 w-48 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div class="h-full bg-green-500 rounded-full animate-progress" style="width: 0%"></div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        // Animate progress bar
        let width = 0;
        const progressBar = modal.querySelector('.animate-progress');
        const interval = setInterval(() => {
            if (width >= 100) {
                clearInterval(interval);
            } else {
                width += 20;
                progressBar.style.width = width + '%';
            }
        }, 400);
    }
    
    function closeProcessingModal() {
        const modal = document.getElementById('processingModal');
        if (modal) {
            modal.remove();
        }
    }
    
    // ==================== LOAD MORE PRODUCTS ====================
    
    let currentPage = 1;
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            currentPage++;
            loadMoreProducts(currentPage);
        });
    }
    
    function loadMoreProducts(page) {
        fetch(`load_products.php?page=${page}`)
            .then(response => response.json())
            .then(data => {
                if (data.products && data.products.length > 0) {
                    const productGrid = document.querySelector('.product-grid');
                    data.products.forEach(product => {
                        productGrid.appendChild(createProductCard(product));
                    });
                } else {
                    loadMoreBtn.style.display = 'none';
                    showNotification('No more products to load', 'info');
                }
            })
            .catch(error => console.error('Error:', error));
    }
    
    function createProductCard(product) {
        const card = document.createElement('div');
        card.className = 'product-card bg-white rounded-2xl shadow-lg overflow-hidden';
        card.innerHTML = `
            <div class="p-6 text-center">
                <div class="text-6xl mb-4">${product.image}</div>
                <h4 class="product-name font-bold text-lg">${product.name}</h4>
                <p class="product-flavor text-purple-600 text-sm">${product.flavor}</p>
                <div class="text-2xl font-bold mt-2">₱${product.price}</div>
                <form method="POST" class="mt-4">
                    <input type="hidden" name="product_id" value="${product.id}">
                    <button type="submit" name="add_to_cart" 
                            class="add-to-cart-btn w-full bg-purple-600 text-white py-2 rounded-full hover:bg-purple-700">
                        Add to Cart
                    </button>
                </form>
            </div>
        `;
        return card;
    }
    
    // ==================== ADD TO WISHLIST ====================
    
    const wishlistButtons = document.querySelectorAll('.add-to-wishlist');
    
    wishlistButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            addToWishlist(productId);
        });
    });
    
    function addToWishlist(productId) {
        fetch('wishlist.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `product_id=${productId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('Added to wishlist! ❤️', 'success');
            } else {
                showNotification('Please login to add to wishlist', 'warning');
            }
        })
        .catch(error => console.error('Error:', error));
    }
    
    // ==================== BACK TO TOP BUTTON ====================
    
    const backToTopBtn = document.getElementById('backToTop');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.style.display = 'flex';
            } else {
                backToTopBtn.style.display = 'none';
            }
        });
        
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
    
    // ==================== ANIMATIONS ON SCROLL ====================
    
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.animate-on-scroll');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (elementPosition < screenPosition) {
                element.classList.add('animated');
            }
        });
    };
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Run once on load
    
    // ==================== COUPON CODE HANDLER ====================
    
    const applyCouponBtn = document.getElementById('applyCoupon');
    
    if (applyCouponBtn) {
        applyCouponBtn.addEventListener('click', function() {
            const couponInput = document.getElementById('couponCode');
            const couponCode = couponInput.value.toUpperCase();
            
            const coupons = {
                'WELCOME10': 10,
                'BEVERAGE20': 20,
                'FREESHIP': 15
            };
            
            if (coupons[couponCode]) {
                const discount = coupons[couponCode];
                showNotification(`Coupon applied! ${discount}% off`, 'success');
                
                // Update total with discount
                const originalTotal = parseFloat(document.querySelector('.cart-total-original')?.dataset.total || 0);
                const discountedTotal = originalTotal * (1 - discount / 100);
                document.querySelector('.cart-total-value').textContent = `₱${discountedTotal.toFixed(2)}`;
            } else {
                showNotification('Invalid coupon code', 'error');
            }
        });
    }
    
    // ==================== PASSWORD SHOW/TOGGLE ====================
    
    const togglePasswordBtns = document.querySelectorAll('.toggle-password');
    
    togglePasswordBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const passwordInput = this.parentElement.querySelector('input');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.textContent = type === 'password' ? '👁️' : '🙈';
        });
    });
    
    // ==================== INITIALIZE ALL FEATURES ====================
    
    function init() {
        initCartButtons();
        initQuantityCounters();
        console.log('BeverageHub JavaScript initialized! 🥤');
    }
    
    init();
    
});
