<?php
session_start();

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if user is logged in
$is_logged_in = isset($_SESSION['client_name']);

// If not logged in, redirect to login page
if (!$is_logged_in) {
    header('Location: login.php');
    exit();
}

// Product data - Shoes, Bags, T-Shirts
$products = [
    1 => [
        'id' => 1, 
        'name' => 'Air Max Pulse', 
        'price' => 1299, 
        'size' => 'US 8-12', 
        'flavor' => 'Running Shoe', 
        'image' => 'img/NIKE+AIR+MAX+PULSE.PNG', 
        'image_alt' => 'Nike Air Max Pulse Sneakers',
        'badge' => 'Limited Edition', 
        'category' => 'shoes'
    ],
    2 => [
        'id' => 2, 
        'name' => 'Classic Backpack', 
        'price' => 899, 
        'size' => '20L', 
        'flavor' => 'Canvas', 
        'image' => 'img/Classic Backpack.jpg', 
        'image_alt' => 'Classic Canvas Backpack',
        'badge' => 'Water Resistant', 
        'category' => 'bags'
    ],
    3 => [
        'id' => 3, 
        'name' => 'Vintage Logo Tee', 
        'price' => 399, 
        'size' => 'S-XXL', 
        'flavor' => 'Cotton', 
        'image' => 'img/Vintage.png', 
        'image_alt' => 'Vintage Logo T-Shirt',
        'badge' => '100% Cotton', 
        'category' => 'tshirts'
    ],
    4 => [
        'id' => 4, 
        'name' => 'Trail Runner Pro', 
        'price' => 1599, 
        'size' => 'US 7-13', 
        'flavor' => 'Trail Shoe', 
        'image' => 'img/Trail runner pro.jpg', 
        'image_alt' => 'Trail Runner Pro Shoes',
        'badge' => 'Grip Sole', 
        'category' => 'shoes'
    ],
    5 => [
        'id' => 5, 
        'name' => 'Leather Messenger Bag', 
        'price' => 1499, 
        'size' => '15" Laptop', 
        'flavor' => 'Genuine Leather', 
        'image' => 'img/LeatherMessengerBag.png', 
        'image_alt' => 'Leather Messenger Bag',
        'badge' => 'Premium', 
        'category' => 'bags'
    ],
    6 => [
        'id' => 6, 
        'name' => 'Oversized Streetwear Tee', 
        'price' => 499, 
        'size' => 'S-XXL', 
        'flavor' => 'Oversized Fit', 
        'image' => 'img/Oversized.jpg', 
        'image_alt' => 'Oversized Streetwear T-Shirt',
        'badge' => 'Streetwear', 
        'category' => 'tshirts'
    ],
    7 => [
        'id' => 7, 
        'name' => 'Retro Runner Sneakers', 
        'price' => 999, 
        'size' => 'US 8-11', 
        'flavor' => 'Retro Style', 
        'image' => 'img/Sneakers.png', 
        'image_alt' => 'Retro Runner Sneakers',
        'badge' => 'Vintage', 
        'category' => 'shoes'
    ],
    8 => [
        'id' => 8, 
        'name' => 'Mini Crossbody Bag', 
        'price' => 599, 
        'size' => 'Small', 
        'flavor' => 'Nylon', 
        'image' => 'img/mini-crossbody.jpg', 
        'image_alt' => 'Mini Crossbody Bag',
        'badge' => 'Lightweight', 
        'category' => 'bags'
    ],
    9 => [
        'id' => 9, 
        'name' => 'Graphic Print Tee', 
        'price' => 449, 
        'size' => 'S-XXL', 
        'flavor' => 'Art Print', 
        'image' => 'img/graphic-print-tees.png', 
        'image_alt' => 'Graphic Print T-Shirt',
        'badge' => 'Unique Design', 
        'category' => 'tshirts'
    ],
    10 => [
        'id' => 10, 
        'name' => 'Slip-On Casual Shoes', 
        'price' => 749, 
        'size' => 'US 7-12', 
        'flavor' => 'Casual', 
        'image' => 'img/casual shoes.jpg', 
        'image_alt' => 'Slip-On Casual Shoes',
        'badge' => 'Easy Wear', 
        'category' => 'shoes'
    ]
];


$category = isset($_GET['category']) ? $_GET['category'] : 'all';


$filtered_products = $products;
if ($category !== 'all') {
    $filtered_products = array_filter($products, function($product) use ($category) {
        return $product['category'] === $category;
    });
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = (int)$_POST['product_id'];
    if (isset($products[$product_id])) {
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity']++;
        } else {
            $_SESSION['cart'][$product_id] = [
                'id' => $product_id,
                'name' => $products[$product_id]['name'],
                'price' => $products[$product_id]['price'],
                'quantity' => 1,
                'image' => $products[$product_id]['image']
            ];
        }
    }
    header('Location: home.php');
    exit();
}


if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}


$cart_count = array_sum(array_column($_SESSION['cart'], 'quantity'));


$current_section = isset($_GET['section']) ? $_GET['section'] : 'home';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EARTHEN STYLE — Premium Shoes, Bags & Tees</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        h1, h2, h3, h4, .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f7f3ef;
        }
        
        .active-nav {
            color: #A0522D !important;
            border-bottom: 2px solid #A0522D;
            padding-bottom: 4px;
        }
        
        .product-card {
            background: white;
            transition: all 0.4s ease;
            border-radius: 24px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        
        .product-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 35px -12px rgba(93, 58, 26, 0.15);
        }
        
        .product-image {
            width: 100%;
            height: 220px;
            object-fit: contain;
            padding: 1rem;
            transition: transform 0.4s ease;
        }
        
        .product-card:hover .product-image {
            transform: scale(1.05);
        }
        
        .btn-primary {
            background: #A0522D;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: #8B4513;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(160, 82, 45, 0.3);
        }
        
        .btn-logout {
            background: #dc2626;
            transition: all 0.3s ease;
        }
        
        .btn-logout:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(220, 38, 38, 0.3);
        }
        
        .hero-section {
            background: linear-gradient(135deg, #2c1810 0%, #3d2a1f 50%, #5c3a2e 100%);
        }
        
        .category-chip {
            background: white;
            border: 1px solid #e8ddd0;
            transition: all 0.3s ease;
        }
        
        .category-chip:hover, .category-chip-active {
            background: #A0522D;
            color: white;
            border-color: #A0522D;
        }
        
        .badge-tag {
            background: linear-gradient(135deg, #A0522D 0%, #8B4513 100%);
        }
        
        .deal-card {
            border-radius: 28px;
            transition: all 0.3s ease;
        }
        
        .deal-card:hover {
            transform: scale(1.02);
        }
        
        .navbar {
            background: rgba(255, 251, 245, 0.98);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(160, 82, 45, 0.1);
        }
        
        ::-webkit-scrollbar {
            width: 6px;
        }
        
        ::-webkit-scrollbar-track {
            background: #e8ddd0;
            border-radius: 10px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #A0522D;
            border-radius: 10px;
        }
        
        .animate-float {
            animation: float 4s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-8px); }
        }
        
        .user-avatar {
            background: linear-gradient(135deg, #A0522D 0%, #8B4513 100%);
        }
    </style>
</head>
<body class="antialiased">
    
    <nav class="navbar sticky top-0 z-50 shadow-sm">
        <div class="container mx-auto px-6 py-4">
            <div class="flex justify-between items-center flex-wrap gap-4">
                <div class="flex items-center gap-3">
                    <div class="text-3xl animate-float">🌿</div>
                    <div>
                        <h1 class="text-2xl font-bold tracking-tight text-gray-800">
                            EARTHEN <span class="text-[#A0522D]">STYLE</span>
                        </h1>
                        <p class="text-xs text-gray-500 tracking-wide">Natural. Timeless. You.</p>
                    </div>
                </div>
                <div class="flex items-center gap-6 flex-wrap">
                    <a href="home.php?section=home" class="text-gray-600 hover:text-[#A0522D] font-medium transition-all duration-300 <?php echo $current_section == 'home' ? 'active-nav' : ''; ?>">
                        Home
                    </a>
                    <a href="home.php?section=shop&category=all" class="text-gray-600 hover:text-[#A0522D] font-medium transition-all duration-300 <?php echo $current_section == 'shop' ? 'active-nav' : ''; ?>">
                        Shop
                    </a>
                    <a href="home.php?section=deals" class="text-gray-600 hover:text-[#A0522D] font-medium transition-all duration-300 <?php echo $current_section == 'deals' ? 'active-nav' : ''; ?>">
                        Deals
                    </a>
                    <a href="cart.php" class="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md transition-all duration-300 text-sm font-medium text-gray-700 border border-gray-200">
                        <span>🛒</span>
                        Cart
                        <?php if($cart_count > 0): ?>
                            <span class="bg-[#A0522D] text-white text-xs rounded-full px-2 py-0.5 ml-1"><?php echo $cart_count; ?></span>
                        <?php endif; ?>
                    </a>
                    
                    
                    <div class="flex items-center gap-3">
                        <div class="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm border border-gray-200">
                            <div class="w-7 h-7 user-avatar rounded-full flex items-center justify-center text-white text-xs font-bold">
                                <?php echo strtoupper(substr($_SESSION['client_name'], 0, 1)); ?>
                            </div>
                            <span class="text-sm font-medium text-gray-700"><?php echo htmlspecialchars($_SESSION['client_name']); ?></span>
                        </div>
                        <a href="?logout=1" class="btn-logout text-white px-5 py-2 rounded-full text-sm font-medium shadow-sm hover:shadow transition-all flex items-center gap-2">
                            <span>🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    
    <?php if ($current_section == 'home'): ?>
    
        <div class="hero-section text-white relative overflow-hidden">
            <div class="absolute inset-0 opacity-20">
                <div class="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
                <div class="absolute bottom-20 right-10 w-96 h-96 bg-white rounded-full blur-3xl"></div>
            </div>
            <div class="container mx-auto px-6 py-24 text-center relative z-10">
                <div class="inline-block bg-white/10 backdrop-blur-sm rounded-full px-6 py-2 mb-6 text-sm font-medium tracking-wide">
                    🌿 Sustainable Fashion
                </div>
                <h2 class="text-5xl sm:text-7xl font-bold mb-6 serif tracking-tight">
                    Earth-Inspired<br>Style
                </h2>
                <p class="text-xl mb-8 max-w-2xl mx-auto opacity-90">
                    Premium Shoes • Leather Bags • Organic Tees
                </p>
                <div class="flex justify-center gap-4 flex-wrap">
                    <a href="home.php?section=shop&category=all" class="bg-white text-[#A0522D] px-8 py-3 rounded-full font-semibold hover:shadow-xl transition-all transform hover:scale-105">
                        Shop Now →
                    </a>
                    <a href="home.php?section=deals" class="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-[#A0522D] transition-all">
                        Explore Deals
                    </a>
                </div>
                <div class="flex justify-center gap-6 mt-12 flex-wrap">
                    <div class="flex items-center gap-2 text-sm">
                        <span>🚚</span> Free Shipping ₱1500+
                    </div>
                    <div class="flex items-center gap-2 text-sm">
                        <span>✨</span> Best Price Guarantee
                    </div>
                    <div class="flex items-center gap-2 text-sm">
                        <span>💳</span> 30-Day Returns
                    </div>
                </div>
            </div>
        </div>

        
        <div class="container mx-auto px-6 py-20">
            <div class="text-center mb-14">
                <div class="inline-block bg-[#A0522D]/10 rounded-full px-4 py-1 mb-4">
                    <span class="text-[#A0522D] text-sm font-medium">Curated Collection</span>
                </div>
                <h3 class="text-3xl sm:text-4xl font-bold text-gray-800 mb-3 serif">
                    Earth's Finest Picks
                </h3>
                <p class="text-gray-500 max-w-md mx-auto">Discover our most wanted styles, handpicked just for you</p>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <?php foreach (array_slice($products, 0, 4) as $product): ?>
                <div class="product-card overflow-hidden group">
                    <div class="relative bg-[#faf6f0] rounded-t-2xl overflow-hidden">
                        <?php if (file_exists($product['image'])): ?>
                            <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['image_alt']; ?>" class="product-image mx-auto">
                        <?php else: ?>
                            <div class="text-8xl text-center py-10">
                                <?php echo $product['category'] == 'shoes' ? '👟' : ($product['category'] == 'bags' ? '🎒' : '👕'); ?>
                            </div>
                        <?php endif; ?>
                        <div class="absolute top-3 right-3 badge-tag text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                            <?php echo $product['badge']; ?>
                        </div>
                    </div>
                    <div class="p-5 text-center">
                        <h4 class="font-bold text-lg mb-1 text-gray-800"><?php echo htmlspecialchars($product['name']); ?></h4>
                        <p class="text-[#A0522D] text-sm font-medium mb-2"><?php echo $product['flavor']; ?></p>
                        <div class="flex justify-center gap-2 mb-3">
                            <span class="bg-gray-100 text-gray-600 text-xs px-3 py-1 rounded-full">
                                📏 <?php echo $product['size']; ?>
                            </span>
                        </div>
                        <p class="text-2xl font-bold text-gray-800 mb-4">₱<?php echo number_format($product['price'], 2); ?></p>
                        <form method="POST">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" name="add_to_cart" 
                                    class="btn-primary w-full text-white font-semibold py-2.5 rounded-full transition-all shadow-sm hover:shadow">
                                🛒 Add to Cart
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-12">
                <a href="home.php?section=shop&category=all" class="inline-flex items-center gap-2 border-2 border-[#A0522D] text-[#A0522D] px-8 py-3 rounded-full font-semibold transition-all hover:bg-[#A0522D] hover:text-white">
                    View All Products <span>→</span>
                </a>
            </div>
        </div>

    <?php elseif ($current_section == 'shop'): ?>

        <div class="hero-section text-white py-20">
            <div class="container mx-auto px-6 text-center">
                <h2 class="text-4xl sm:text-5xl font-bold mb-4 serif">Our Collection</h2>
                <p class="text-lg opacity-90">Find pieces that speak to your soul</p>
            </div>
        </div>

        <div class="container mx-auto px-6 py-16">
            
            <div class="flex flex-wrap justify-center gap-3 mb-12">
                <a href="home.php?section=shop&category=all" 
                   class="category-chip px-5 py-2 rounded-full text-sm font-medium transition-all <?php echo $category == 'all' ? 'category-chip-active' : 'text-gray-700'; ?>">
                    All Items
                </a>
                <a href="home.php?section=shop&category=shoes" 
                   class="category-chip px-5 py-2 rounded-full text-sm font-medium transition-all <?php echo $category == 'shoes' ? 'category-chip-active' : 'text-gray-700'; ?>">
                    👟 Shoes
                </a>
                <a href="home.php?section=shop&category=bags" 
                   class="category-chip px-5 py-2 rounded-full text-sm font-medium transition-all <?php echo $category == 'bags' ? 'category-chip-active' : 'text-gray-700'; ?>">
                    🎒 Bags
                </a>
                <a href="home.php?section=shop&category=tshirts" 
                   class="category-chip px-5 py-2 rounded-full text-sm font-medium transition-all <?php echo $category == 'tshirts' ? 'category-chip-active' : 'text-gray-700'; ?>">
                    👕 T-Shirts
                </a>
            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                <?php if (count($filtered_products) > 0): ?>
                    <?php foreach ($filtered_products as $product): ?>
                    <div class="product-card overflow-hidden group">
                        <div class="relative bg-[#faf6f0] rounded-t-2xl overflow-hidden">
                            <?php if (file_exists($product['image'])): ?>
                                <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['image_alt']; ?>" class="product-image mx-auto">
                            <?php else: ?>
                                <div class="text-8xl text-center py-10">
                                    <?php echo $product['category'] == 'shoes' ? '👟' : ($product['category'] == 'bags' ? '🎒' : '👕'); ?>
                                </div>
                            <?php endif; ?>
                            <div class="absolute top-3 right-3 badge-tag text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                                <?php echo $product['badge']; ?>
                            </div>
                        </div>
                        <div class="p-5 text-center">
                            <h4 class="font-bold text-lg mb-1 text-gray-800"><?php echo htmlspecialchars($product['name']); ?></h4>
                            <p class="text-[#A0522D] text-sm font-medium mb-2"><?php echo $product['flavor']; ?></p>
                            <div class="flex justify-center gap-2 mb-3">
                                <span class="bg-gray-100 text-gray-600 text-xs px-3 py-1 rounded-full">
                                    📏 <?php echo $product['size']; ?>
                                </span>
                            </div>
                            <p class="text-2xl font-bold text-gray-800 mb-4">₱<?php echo number_format($product['price'], 2); ?></p>
                            <form method="POST">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" name="add_to_cart" 
                                        class="btn-primary w-full text-white font-semibold py-2.5 rounded-full transition-all shadow-sm hover:shadow">
                                    🛒 Add to Cart
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-span-full text-center py-20">
                        <div class="text-6xl mb-4">🔍</div>
                        <p class="text-gray-500 text-lg">No products found in this category.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    <?php elseif ($current_section == 'deals'): ?>

        <div class="hero-section text-white py-20">
            <div class="container mx-auto px-6 text-center">
                <h2 class="text-4xl sm:text-5xl font-bold mb-4 serif">🎉 Special Offers</h2>
                <p class="text-lg opacity-90">Limited time deals you won't want to miss</p>
            </div>
        </div>

        <div class="container mx-auto px-6 py-16">
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                <div class="deal-card bg-gradient-to-br from-amber-500 to-orange-600 p-8 text-white shadow-xl">
                    <div class="flex justify-between items-start">
                        <div>
                            <span class="bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold">🔥 LIMITED</span>
                            <h3 class="text-2xl font-bold mt-4">Buy 2<br>Get 1 Free</h3>
                            <p class="text-sm mt-2 opacity-90">On t-shirts & bags</p>
                        </div>
                        <div class="text-5xl">🎁</div>
                    </div>
                </div>
                <div class="deal-card bg-gradient-to-br from-emerald-600 to-teal-700 p-8 text-white shadow-xl">
                    <div class="flex justify-between items-start">
                        <div>
                            <span class="bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold">⚡ FLASH</span>
                            <h3 class="text-2xl font-bold mt-4">Free Shipping<br>₱1500+</h3>
                            <p class="text-sm mt-2 opacity-90">Code: EARTHSHIP</p>
                        </div>
                        <div class="text-5xl">🚚</div>
                    </div>
                </div>
                <div class="deal-card bg-gradient-to-br from-amber-800 to-amber-900 p-8 text-white shadow-xl">
                    <div class="flex justify-between items-start">
                        <div>
                            <span class="bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold">🎯 WEEKEND</span>
                            <h3 class="text-2xl font-bold mt-4">20% Off<br>All Shoes</h3>
                            <p class="text-sm mt-2 opacity-90">Sat & Sun only</p>
                        </div>
                        <div class="text-5xl">👟</div>
                    </div>
                </div>
            </div>

            
            <div class="text-center mb-12">
                <h3 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-2 serif">🏷️ On Sale Now</h3>
                <p class="text-gray-500">Limited quantities — grab yours before they're gone</p>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php 
                $sale_products = array_slice($products, 0, 3);
                foreach ($sale_products as $product): 
                ?>
                <div class="product-card overflow-hidden relative">
                    <div class="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold z-10 shadow-md">
                        -20% OFF
                    </div>
                    <div class="relative bg-[#faf6f0] rounded-t-2xl overflow-hidden">
                        <?php if (file_exists($product['image'])): ?>
                            <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['image_alt']; ?>" class="product-image mx-auto">
                        <?php else: ?>
                            <div class="text-8xl text-center py-10">
                                <?php echo $product['category'] == 'shoes' ? '👟' : ($product['category'] == 'bags' ? '🎒' : '👕'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="p-5 text-center">
                        <h4 class="font-bold text-lg mb-1 text-gray-800"><?php echo htmlspecialchars($product['name']); ?></h4>
                        <p class="text-[#A0522D] text-sm font-medium mb-2"><?php echo $product['flavor']; ?></p>
                        <div class="flex justify-center gap-2 mb-3">
                            <span class="bg-gray-100 text-gray-600 text-xs px-3 py-1 rounded-full">
                                📏 <?php echo $product['size']; ?>
                            </span>
                        </div>
                        <div class="mb-4">
                            <span class="text-gray-400 line-through text-sm">₱<?php echo number_format($product['price'], 2); ?></span>
                            <span class="text-2xl font-bold text-red-600 ml-2">₱<?php echo number_format($product['price'] * 0.8, 2); ?></span>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" name="add_to_cart" 
                                    class="w-full bg-gradient-to-r from-red-500 to-orange-500 text-white font-semibold py-2.5 rounded-full transition-all transform hover:scale-105 shadow-md hover:shadow-lg">
                                ⚡ Grab Deal
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    
    <footer class="bg-[#2c1810] text-white pt-16 pb-8 mt-12">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                <div>
                    <div class="flex items-center gap-2 mb-4">
                        <span class="text-2xl">🌿</span>
                        <h4 class="text-xl font-bold serif">EARTHEN STYLE</h4>
                    </div>
                    <p class="text-gray-400 text-sm">Natural. Timeless. You.</p>
                </div>
                <div>
                    <h5 class="font-semibold mb-3">Shop</h5>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="home.php?section=shop&category=shoes" class="hover:text-white transition">Shoes</a></li>
                        <li><a href="home.php?section=shop&category=bags" class="hover:text-white transition">Bags</a></li>
                        <li><a href="home.php?section=shop&category=tshirts" class="hover:text-white transition">T-Shirts</a></li>
                    </ul>
                </div>
                <div>
                    <h5 class="font-semibold mb-3">Support</h5>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="#" class="hover:text-white transition">Contact Us</a></li>
                        <li><a href="#" class="hover:text-white transition">FAQs</a></li>
                        <li><a href="#" class="hover:text-white transition">Returns</a></li>
                    </ul>
                </div>
                <div>
                    <h5 class="font-semibold mb-3">Follow Us</h5>
                    <div class="flex gap-3 text-xl">
                        <a href="#" class="hover:text-[#A0522D] transition">📘</a>
                        <a href="#" class="hover:text-[#A0522D] transition">📷</a>
                        <a href="#" class="hover:text-[#A0522D] transition">🐦</a>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
                <p>© 2026 EARTHEN STYLE — Natural. Timeless. You.</p>
                <p class="mt-1">Shoes | Bags | T-Shirts | Accessories</p>
            </div>
        </div>
    </footer>
</body>
</html>