-- Create database
CREATE DATABASE IF NOT EXISTS earthen_style;
USE earthen_style;

-- Users table (for admin accounts)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'super_admin') DEFAULT 'admin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
);

-- Brands table
CREATE TABLE IF NOT EXISTS brands (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    logo VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brand_id INT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100),
    size_options VARCHAR(255),
    stock_quantity INT DEFAULT 0,
    image VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE SET NULL
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20),
    customer_address TEXT,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'approved', 'disapproved', 'cancelled', 'delivered') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    product_name VARCHAR(200),
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100),
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Insert default admin account (password: admin123)
INSERT INTO users (username, email, password, full_name, role) VALUES 
('admin', 'admin@earthenstyle.com', '$2y$10$YourHashHere', 'Administrator', 'super_admin');

-- Insert sample brands
INSERT INTO brands (name, description, status) VALUES
('Nike', 'Leading athletic footwear and apparel', 'active'),
('The North Face', 'Outdoor recreation products', 'active'),
('Adidas', 'German athletic apparel and footwear', 'active'),
('Patagonia', 'Sustainable outdoor clothing', 'active');

-- Insert sample products
INSERT INTO products (brand_id, name, description, price, category, size_options, stock_quantity, status) VALUES
(1, 'Air Max Pulse', 'Premium running shoe with maximum cushioning', 1299.00, 'Footwear', 'US 8-12', 50, 'active'),
(2, 'Classic Backpack', 'Durable canvas backpack for everyday use', 899.00, 'Bags', 'One Size', 30, 'active'),
(3, 'Vintage Logo Tee', 'Classic cotton t-shirt with vintage logo', 399.00, 'Apparel', 'S-XXL', 100, 'active'),
(1, 'Trail Runner Pro', 'Professional trail running shoes', 1599.00, 'Footwear', 'US 7-13', 40, 'active');

-- Insert new products
INSERT INTO products (brand_id, name, description, price, category, size_options, stock_quantity, status) VALUES
(1, 'Leather Messenger Bag', 'Genuine Leather, 15" Laptop Compatible', 1499.00, 'Bags', 'One Size', 25, 'active'),
(2, 'Oversized Streetwear Tee', 'Oversized Fit, Premium Cotton, S-XXL', 499.00, 'Apparel', 'S-XXL', 50, 'active'),
(3, 'Retro Runner Sneakers', 'Retro Style, Comfortable Fit, US 8-11', 999.00, 'Footwear', 'US 8-11', 35, 'active'),
(4, 'Mini Crossbody Bag', 'Lightweight Nylon, Small Size, Perfect for Daily Use', 599.00, 'Bags', 'One Size', 40, 'active');

-- Also add the tags/categories if needed
UPDATE products SET 
    description = CASE 
        WHEN name = 'Leather Messenger Bag' THEN 'Premium genuine leather messenger bag. Fits 15" laptop. Durable and stylish for everyday use.'
        WHEN name = 'Oversized Streetwear Tee' THEN 'Oversized fit streetwear t-shirt. Made from premium cotton. Available in S-XXL sizes.'
        WHEN name = 'Retro Runner Sneakers' THEN 'Retro style running sneakers. Comfortable cushioning. Available in US sizes 8-11.'
        WHEN name = 'Retro Runner Sneakers' THEN 'Lightweight nylon mini crossbody bag. Perfect for essentials. Compact and stylish.'
        ELSE description
    END;