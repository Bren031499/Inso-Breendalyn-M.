<?php
// config/mysqli_connect.php
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'earthen_style';

$conn = mysqli_connect($db_host, $db_user, $db_password);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "CREATE DATABASE IF NOT EXISTS $db_name CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if (mysqli_query($conn, $sql)) {
    
    mysqli_select_db($conn, $db_name);
    
    
    $tables_sql = "
    -- Users table
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100) NOT NULL,
        role ENUM('admin', 'super_admin') DEFAULT 'admin',
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL
    );
    
    -- Brands table
    CREATE TABLE IF NOT EXISTS brands (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        logo VARCHAR(255),
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    
    -- Products table
    CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        brand_id INT,
        name VARCHAR(200) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        category VARCHAR(100),
        size_options VARCHAR(255),
        stock_quantity INT DEFAULT 0,
        image VARCHAR(255),
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE SET NULL
    );
    
    -- Orders table
    CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_number VARCHAR(50) UNIQUE NOT NULL,
        customer_name VARCHAR(100) NOT NULL,
        customer_email VARCHAR(100) NOT NULL,
        customer_phone VARCHAR(20),
        customer_address TEXT,
        total_amount DECIMAL(10, 2) NOT NULL,
        status ENUM('pending', 'approved', 'disapproved', 'cancelled', 'delivered') DEFAULT 'pending',
        payment_method VARCHAR(50),
        payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    
    -- Order items table
    CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        product_id INT,
        product_name VARCHAR(200),
        quantity INT NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        subtotal DECIMAL(10, 2) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
    );
    
    -- Activity logs table
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        action VARCHAR(100),
        description TEXT,
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );";
    

    if (mysqli_multi_query($conn, $tables_sql)) {
        do {
        
            while (mysqli_more_results($conn) && mysqli_next_result($conn)) {
                // Skip
            }
        } while (false);
    }
    
    
    $check_admin = mysqli_query($conn, "SELECT id FROM users WHERE username = 'admin'");
    if (mysqli_num_rows($check_admin) == 0) {
        $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
        $insert_admin = "INSERT INTO users (username, email, password, full_name, role, status) VALUES 
                        ('admin', 'admin@earthenstyle.com', '$hashed_password', 'Administrator', 'super_admin', 'active')";
        mysqli_query($conn, $insert_admin);
    
    }
    
    
    $check_brands = mysqli_query($conn, "SELECT id FROM brands LIMIT 1");
    if (mysqli_num_rows($check_brands) == 0) {
        mysqli_query($conn, "INSERT INTO brands (name, description, status) VALUES
                            ('Nike', 'Leading athletic footwear and apparel', 'active'),
                            ('The North Face', 'Outdoor recreation products', 'active'),
                            ('Adidas', 'German athletic apparel and footwear', 'active'),
                            ('Patagonia', 'Sustainable outdoor clothing', 'active')");
    }
    
    
    $check_products = mysqli_query($conn, "SELECT id FROM products LIMIT 1");
    if (mysqli_num_rows($check_products) == 0) {
        mysqli_query($conn, "INSERT INTO products (brand_id, name, description, price, category, size_options, stock_quantity, status) VALUES
                            (1, 'Air Max Pulse', 'Premium running shoe with maximum cushioning', 1299.00, 'Footwear', 'US 8-12', 50, 'active'),
                            (2, 'Classic Backpack', 'Durable canvas backpack for everyday use', 899.00, 'Bags', 'One Size', 30, 'active'),
                            (3, 'Vintage Logo Tee', 'Classic cotton t-shirt with vintage logo', 399.00, 'Apparel', 'S-XXL', 100, 'active'),
                            (1, 'Trail Runner Pro', 'Professional trail running shoes', 1599.00, 'Footwear', 'US 7-13', 40, 'active')");
    }
    
} else {
    die("Error creating database: " . mysqli_error($conn));
}


mysqli_set_charset($conn, "utf8");


function executeQuery($conn, $sql, $params = []) {
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt && !empty($params)) {
        $types = str_repeat('s', count($params));
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    mysqli_stmt_execute($stmt);
    return $stmt;
}
?>