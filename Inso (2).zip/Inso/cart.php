<?php
// Start session only once
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


if (isset($_GET['remove'])) {
    $product_id = (int)$_GET['remove'];
    unset($_SESSION['cart'][$product_id]);
    header('Location: cart.php');
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $id => $qty) {
        $id = (int)$id;
        $qty = (int)$qty;
        if ($qty <= 0) {
            unset($_SESSION['cart'][$id]);
        } else {
            $_SESSION['cart'][$id]['quantity'] = $qty;
        }
    }
    header('Location: cart.php');
    exit();
}

$cart_items = $_SESSION['cart'];
$cart_total = array_sum(array_map(function($item) {
    return $item['price'] * $item['quantity'];
}, $cart_items));
$cart_count = array_sum(array_column($cart_items, 'quantity'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Earthen Style</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        h1, h2, h3, .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f7f3ef;
        }
        
        /* Cart Item Card Style */
        .cart-item {
            background: white;
            border-radius: 20px;
            transition: all 0.3s ease;
            border: 1px solid #f0e6dc;
        }
        
        .cart-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px -8px rgba(93, 58, 26, 0.12);
            border-color: #e0d0c0;
        }
        
        .product-img {
            width: 80px;
            height: 80px;
            background: #faf6f0;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            transition: transform 0.3s ease;
        }
        
        .product-img:hover {
            transform: scale(1.05);
        }
        
        .quantity-control {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #faf6f0;
            padding: 4px 8px;
            border-radius: 40px;
        }
        
        .qty-btn {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: white;
            border: 1px solid #e0d0c0;
            color: #8B5A2B;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        .qty-btn:hover {
            background: #8B5A2B;
            color: white;
            border-color: #8B5A2B;
            transform: scale(1.05);
        }
        
        .qty-input {
            width: 50px;
            text-align: center;
            border: none;
            background: transparent;
            font-weight: 600;
            font-size: 1rem;
            padding: 8px 0;
        }
        
        .qty-input:focus {
            outline: none;
        }
        
        .remove-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #fef2f2;
            color: #ef4444;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .remove-btn:hover {
            background: #fee2e2;
            transform: scale(1.05);
            color: #dc2626;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #A0522D 0%, #8B4513 100%);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #8B4513 0%, #6B3410 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(160, 82, 45, 0.3);
        }
        
        .btn-secondary {
            border: 2px solid #A0522D;
            color: #A0522D;
            background: transparent;
            transition: all 0.3s ease;
        }
        
        .btn-secondary:hover {
            background: #A0522D;
            color: white;
            transform: translateY(-2px);
        }
        
        .navbar {
            background: rgba(255, 251, 245, 0.98);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(160, 82, 45, 0.1);
        }
        
        .empty-cart {
            background: linear-gradient(135deg, #fff9f5 0%, #fff5ed 100%);
            border-radius: 32px;
        }
        
        .summary-card {
            background: linear-gradient(135deg, #faf6f0 0%, #f5efe8 100%);
            border-radius: 24px;
            padding: 24px;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
        }
        .animate-float {
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        .animate-bounce-slow {
            animation: bounce 2s ease-in-out infinite;
        }
        
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button {
            opacity: 1;
        }
    </style>
</head>
<body>
    
    <nav class="navbar sticky top-0 z-50 shadow-sm">
        <div class="container mx-auto px-6 py-4">
            <div class="flex justify-between items-center flex-wrap gap-4">
                <a href="home.php" class="flex items-center gap-3 group">
                    <div class="text-3xl animate-float">👜</div>
                    <div>
                        <h1 class="text-2xl font-bold tracking-tight">
                            <span class="serif text-gray-800">EARTHEN</span>
                            <span class="serif text-[#A0522D]"> STYLE</span>
                        </h1>
                        <p class="text-xs text-gray-500 tracking-wide">Natural. Timeless. You.</p>
                    </div>
                </a>
                <a href="home.php" class="flex items-center gap-2 text-amber-700 hover:text-amber-800 font-medium transition-all group">
                    <span class="group-hover:-translate-x-1 transition-transform">←</span>
                    Continue Shopping
                </a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-6 py-12">
        <div class="max-w-5xl mx-auto">
        
            <div class="text-center mb-10">
                <div class="inline-block bg-[#A0522D]/10 rounded-full px-4 py-1 mb-3">
                    <span class="text-[#A0522D] text-sm font-medium">Your Selection</span>
                </div>
                <h2 class="text-3xl sm:text-4xl font-bold text-gray-800 serif">🛍️ Shopping Cart</h2>
                <p class="text-gray-500 mt-2">Review and manage your items</p>
            </div>
            
            <?php if (empty($cart_items)): ?>
                
                <div class="empty-cart text-center py-16 px-6 shadow-xl border border-amber-100">
                    <div class="text-7xl mb-5 animate-bounce-slow">🛒</div>
                    <div class="w-24 h-1 bg-gradient-to-r from-amber-300 to-amber-500 rounded-full mx-auto mb-6"></div>
                    <h3 class="text-2xl font-bold text-amber-800 mb-3 serif">Your cart is empty</h3>
                    <p class="text-amber-600 mb-8">Looks like you haven't added any items yet.</p>
                    <a href="home.php" class="inline-flex items-center gap-2 btn-primary text-white px-8 py-3 rounded-full font-semibold hover:shadow-xl transition-all">
                        <span>🌿</span> Start Shopping
                    </a>
                </div>
            <?php else: ?>
        
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    <div class="lg:col-span-2 space-y-4">
                        <?php foreach ($cart_items as $id => $item): ?>
                        <div class="cart-item p-5">
                            <div class="flex flex-wrap sm:flex-nowrap gap-5">
                        
<div class="product-img flex-shrink-0">
    <?php if (isset($item['image']) && !empty($item['image']) && file_exists($item['image'])): ?>
        <img src="<?php echo htmlspecialchars($item['image']); ?>" 
             alt="<?php echo htmlspecialchars($item['name']); ?>"
             class="w-full h-full object-cover rounded-2xl">
    <?php else: ?>
    
        <div class="w-full h-full flex items-center justify-center text-3xl">
            <?php
            
            $fallback_emoji = '👜';
            if (stripos($item['name'], 'shoe') !== false || stripos($item['name'], 'air') !== false) $fallback_emoji = '👟';
            elseif (stripos($item['name'], 'backpack') !== false) $fallback_emoji = '🎒';
            elseif (stripos($item['name'], 'tee') !== false || stripos($item['name'], 'shirt') !== false) $fallback_emoji = '👕';
            echo $fallback_emoji;
            ?>
        </div>
    <?php endif; ?>
</div>
                                
                                
                                <div class="flex-1">
                                    <div class="flex flex-wrap justify-between items-start gap-2">
                                        <div>
                                            <h4 class="font-extrabold text-lg text-gray-800"><?php echo htmlspecialchars($item['name']); ?></h4>
                                            <p class="text-sm text-amber-600 mt-0.5">₱<?php echo number_format($item['price'], 2); ?> each</p>
                                        </div>
                                        <div class="remove-btn" onclick="if(confirm('Remove this item from your cart?')) window.location.href='?remove=<?php echo $id; ?>'">
                                            ✕
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="flex flex-wrap justify-between items-center mt-4 pt-3 border-t border-amber-100">
                                        <div class="quantity-control">
                                            <button class="qty-btn" onclick="updateQuantity(<?php echo $id; ?>, <?php echo $item['quantity'] - 1; ?>)">−</button>
                                            <input type="number" id="qty-<?php echo $id; ?>" value="<?php echo $item['quantity']; ?>" min="1" max="99" class="qty-input">
                                            <button class="qty-btn" onclick="updateQuantity(<?php echo $id; ?>, <?php echo $item['quantity'] + 1; ?>)">+</button>
                                        </div>
                                        <div class="text-right">
                                            <p class="text-xs text-gray-500">Subtotal</p>
                                            <p class="font-extrabold text-xl text-amber-700">₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                    
                        <form id="updateCartForm" method="POST" style="display: none;">
                            <input type="hidden" name="update_cart" value="1">
                            <div id="quantityInputs"></div>
                        </form>
                    </div>
                    
                    
                    <div class="lg:col-span-1">
                        <div class="summary-card sticky top-28">
                            <h3 class="text-xl font-bold text-gray-800 serif mb-4 flex items-center gap-2">
                                <span>📋</span> Order Summary
                            </h3>
                            
                            <div class="space-y-3 mb-5">
                                <div class="flex justify-between text-gray-600">
                                    <span>Subtotal</span>
                                    <span class="font-semibold">₱<?php echo number_format($cart_total, 2); ?></span>
                                </div>
                                <div class="flex justify-between text-gray-600">
                                    <span>Shipping</span>
                                    <span class="text-green-600">Free</span>
                                </div>
                                <div class="flex justify-between text-gray-600 border-t border-amber-200 pt-3">
                                    <span class="font-bold text-gray-800">Total</span>
                                    <span class="font-extrabold text-2xl text-amber-700">₱<?php echo number_format($cart_total, 2); ?></span>
                                </div>
                            </div>
                            
                            <div class="bg-amber-100/50 rounded-xl p-3 mb-5 text-center">
                                <p class="text-xs text-amber-700">🚚 Free shipping on orders ₱1500+</p>
                            </div>
                            
                            <button onclick="submitCartUpdate(); alert('✅ Order placed successfully! Total: ₱<?php echo number_format($cart_total, 2); ?>')" 
                                    class="btn-primary w-full text-white py-3 rounded-full font-bold shadow-md hover:shadow-xl transition-all flex items-center justify-center gap-2">
                                <span>✅</span> Proceed to Checkout
                            </button>
                            
                            <div class="mt-4 text-center">
                                <a href="home.php" class="text-amber-600 hover:text-amber-800 text-sm transition flex items-center justify-center gap-1">
                                    ← Continue Shopping
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function updateQuantity(productId, newQuantity) {
            if (newQuantity < 1) return;
            if (newQuantity > 99) return;
            
            const qtyInput = document.getElementById('qty-' + productId);
            if (qtyInput) {
                qtyInput.value = newQuantity;
            }
            submitCartUpdate();
        }
        
        function submitCartUpdate() {
            const form = document.getElementById('updateCartForm');
            const inputsContainer = document.getElementById('quantityInputs');
            inputsContainer.innerHTML = '';
            
            <?php foreach ($cart_items as $id => $item): ?>
            const qtyInput<?php echo $id; ?> = document.getElementById('qty-<?php echo $id; ?>');
            if (qtyInput<?php echo $id; ?>) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'quantity[<?php echo $id; ?>]';
                input.value = qtyInput<?php echo $id; ?>.value;
                inputsContainer.appendChild(input);
            }
            <?php endforeach; ?>
            
            form.submit();
        }
        
    
        document.querySelectorAll('.qty-input').forEach(input => {
            input.addEventListener('change', function() {
                let val = parseInt(this.value);
                if (isNaN(val) || val < 1) val = 1;
                if (val > 99) val = 99;
                this.value = val;
                submitCartUpdate();
            });
        });
    </script>
</body>
</html>