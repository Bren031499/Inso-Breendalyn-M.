<?php
session_start();

$error = '';
$success = '';

if (isset($_SESSION['client_id']) && isset($_SESSION['client_email'])) {
    header("Location: home.php");
    exit;
}


if (!isset($_SESSION['users'])) {
    $_SESSION['users'] = [];
}


if (isset($_SESSION['register_success'])) {
    $success = $_SESSION['register_success'];
    unset($_SESSION['register_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        
        $user_found = null;
        foreach ($_SESSION['users'] as $user) {
            if ($user['email'] === $email && $user['password'] === $password) {
                $user_found = $user;
                break;
            }
        }
        
        if ($user_found) {
            
            $_SESSION['client_id'] = $user_found['user_id'];
            $_SESSION['client_name'] = $user_found['fullname'];
            $_SESSION['client_email'] = $user_found['email'];
            $_SESSION['logged_in'] = true;
            $_SESSION['login_time'] = time();
            
            
            header("Location: home.php");
            exit;
        } else {
            $error = "Invalid email or password. Please try again or <a href='register.php' class='underline'>register</a>.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EARTHEN STYLE</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        h1, h2, .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: linear-gradient(135deg, #2c1810 0%, #3d2a1f 50%, #5c3a2e 100%);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }
        
        .btn-login {
            background: linear-gradient(135deg, #A0522D 0%, #8B4513 100%);
            transition: all 0.3s ease;
        }
        
        .btn-login:hover {
            background: linear-gradient(135deg, #8B4513 0%, #6B3410 100%);
            transform: scale(1.02);
            box-shadow: 0 10px 25px -5px rgba(160, 82, 45, 0.4);
        }
        
        .input-focus:focus {
            border-color: #A0522D;
            ring-color: #A0522D;
            box-shadow: 0 0 0 3px rgba(160, 82, 45, 0.2);
        }
        
        .login-card {
            background: rgba(255, 251, 245, 0.98);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(160, 82, 45, 0.2);
        }
        
        .animate-float {
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
        }
        
        .leaf-bg {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            opacity: 0.05;
            pointer-events: none;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4 relative">
    <div class="leaf-bg text-9xl text-center text-white">🌿🍂🌾🍃</div>
    
    <div class="login-card rounded-2xl shadow-2xl p-8 w-full max-w-md fade-in relative z-10">
        <div class="text-center mb-8">
            <div class="text-5xl mb-3 animate-float">🌿</div>
            <a href="home.php" class="text-3xl font-bold tracking-tight">
                <span class="serif text-gray-800">EARTHEN</span>
                <span class="serif text-[#A0522D]"> STYLE</span>
            </a>
            <p class="text-gray-600 mt-2">Sign in to your account</p>
            <p class="text-xs text-gray-500 mt-1">Natural. Timeless. You.</p>
        </div>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4 flex items-start">
                <i class="fas fa-exclamation-circle mt-0.5 mr-2"></i>
                <span><?php echo $error; ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 flex items-start">
                <i class="fas fa-check-circle mt-0.5 mr-2"></i>
                <span><?php echo $success; ?></span>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="loginForm">
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold mb-2">
                    <i class="fas fa-envelope mr-2 text-[#A0522D]"></i>Email Address
                </label>
                <input type="email" name="email" required 
                       class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-[#A0522D] focus:ring-2 focus:ring-[#A0522D]/20 transition"
                       placeholder="you@example.com">
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 font-semibold mb-2">
                    <i class="fas fa-lock mr-2 text-[#A0522D]"></i>Password
                </label>
                <input type="password" name="password" required 
                       class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-[#A0522D] focus:ring-2 focus:ring-[#A0522D]/20 transition"
                       placeholder="Enter your password">
            </div>
            <button type="submit" 
                    class="btn-login w-full text-white font-bold py-3 rounded-lg transition flex items-center justify-center gap-2 shadow-md hover:shadow-xl">
                <i class="fas fa-leaf"></i>
                Sign In
            </button>
        </form>
        
        <div class="text-center mt-6">
            <p class="text-gray-600">
                Don't have an account? 
                <a href="register.php" class="text-[#A0522D] hover:underline font-semibold transition">
                    Create Account <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </p>
        </div>
        
        <div class="mt-6 text-center">
            <a href="home.php" class="text-gray-500 hover:text-[#A0522D] text-sm transition flex items-center justify-center gap-1">
                <i class="fas fa-arrow-left"></i> Back to Store
            </a>
        </div>
    </div>

    <script>
        
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const email = document.querySelector('input[name="email"]').value;
            const password = document.querySelector('input[name="password"]').value;
            
            if (!email || !password) {
                e.preventDefault();
                alert('Please fill in all fields');
            }
        });
    </script>
</body>
</html>