<?php
session_start();
require_once '../config/db_connect.php';

if(!isset($_SESSION['client_id'])) {
    header("Location: login.php");
    exit;
}

$clientId = $_SESSION['client_id'];
$orders = mysqli_query($conn, "SELECT o.*, os.status_name, pm.mode_name 
                                FROM orders o 
                                JOIN order_statuses os ON o.status_id=os.id 
                                JOIN payment_modes pm ON o.payment_mode_id=pm.id 
                                WHERE o.client_id=$clientId 
                                ORDER BY o.order_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - UrbanCart</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="home.php" class="text-2xl font-bold text-blue-600">🛒 UrbanCart</a>
            <div>
                <span class="mr-4">Hi, <?php echo htmlspecialchars($_SESSION['client_name']); ?></span>
                <a href="cart.php" class="mr-3 text-gray-700">Cart</a>
                <a href="logout.php" class="text-red-500">Logout</a>
            </div>
        </div>
    </nav>
    
    <div class="container mx-auto p-6">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-2xl font-bold mb-6">My Order History</h2>
            
            <?php if(isset($_GET['success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    Order placed successfully!
                </div>
            <?php endif; ?>
            
            <?php if(mysqli_num_rows($orders) == 0): ?>
                <div class="bg-white rounded-lg shadow-md p-8 text-center">
                    <p class="text-gray-500 mb-4">You haven't placed any orders yet.</p>
                    <a href="home.php" class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600">
                        Start Shopping
                    </a>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php while($ord = mysqli_fetch_assoc($orders)): ?>
                        <div class="bg-white rounded-lg shadow-md p-6">
                            <div class="flex justify-between items-start mb-3">
                                <div>
                                    <p class="text-gray-500 text-sm">Order #<?php echo $ord['id']; ?></p>
                                    <p class="text-gray-500 text-sm">Placed on: <?php echo date('F j, Y', strtotime($ord['order_date'])); ?></p>
                                </div>
                                <div>
                                    <span class="px-3 py-1 rounded-full text-sm font-semibold
                                        <?php 
                                        echo match($ord['status_name']) {
                                            'Pending' => 'bg-yellow-100 text-yellow-800',
                                            'Approved' => 'bg-blue-100 text-blue-800',
                                            'Delivered' => 'bg-green-100 text-green-800',
                                            'Cancelled', 'Disapproved' => 'bg-red-100 text-red-800',
                                            default => 'bg-gray-100 text-gray-800'
                                        };
                                        ?>">
                                        <?php echo $ord['status_name']; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="border-t pt-3">
                                <p class="text-lg font-bold text-blue-600">$<?php echo number_format($ord['total_amount'], 2); ?></p>
                                <p class="text-gray-600 text-sm">Payment: <?php echo htmlspecialchars($ord['mode_name']); ?></p>
                                <p class="text-gray-600 text-sm">Shipping to: <?php echo htmlspecialchars($ord['shipping_address']); ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>