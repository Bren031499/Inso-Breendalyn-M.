<?php
session_start();
require_once '../config/db_connect.php';

if(!isset($_SESSION['client_id'])) {
    header("Location: login.php");
    exit;
}

$clientId = $_SESSION['client_id'];


$cartCheck = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM shopping_cart WHERE client_id=$clientId");
$cartCount = mysqli_fetch_assoc($cartCheck)['cnt'];

if($cartCount == 0) {
    header("Location: cart.php");
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $paymentMode = intval($_POST['payment_mode']);
    

    $cartRes = mysqli_query($conn, "SELECT sc.product_id, sc.quantity, p.price 
                                     FROM shopping_cart sc 
                                     JOIN products p ON sc.product_id=p.id 
                                     WHERE sc.client_id=$clientId");
    
    if(mysqli_num_rows($cartRes) == 0) {
        header("Location: cart.php");
        exit;
    }
    
    $total = 0;
    $items = [];
    while($item = mysqli_fetch_assoc($cartRes)) {
        $sub = $item['price'] * $item['quantity'];
        $total += $sub;
        $items[] = $item;
    }
    
    $pendingStatusId = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM order_statuses WHERE status_name='Pending'"))['id'];
    
    $stmtOrd = mysqli_prepare($conn, "INSERT INTO orders (client_id, total_amount, status_id, payment_mode_id, shipping_address) VALUES (?,?,?,?,?)");
    mysqli_stmt_bind_param($stmtOrd, "iddis", $clientId, $total, $pendingStatusId, $paymentMode, $address);
    mysqli_stmt_execute($stmtOrd);
    $orderId = mysqli_insert_id($conn);
    
    foreach($items as $it) {
        $stmtItem = mysqli_prepare($conn, "INSERT INTO order_items (order_id, product_id, quantity, price_at_time) VALUES (?,?,?,?)");
        mysqli_stmt_bind_param($stmtItem, "iiid", $orderId, $it['product_id'], $it['quantity'], $it['price']);
        mysqli_stmt_execute($stmtItem);
        
        
        mysqli_query($conn, "UPDATE products SET stock = stock - {$it['quantity']} WHERE id={$it['product_id']}");
    }
    

    mysqli_query($conn, "DELETE FROM shopping_cart WHERE client_id=$clientId");
    
    header("Location: order_history.php?success=ordered");
    exit;
}

$paymentOptions = mysqli_query($conn, "SELECT * FROM payment_modes");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - UrbanCart</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="home.php" class="text-2xl font-bold text-blue-600">🛒 UrbanCart</a>
            <a href="cart.php" class="text-gray-700">← Back to Cart</a>
        </div>
    </nav>
    
    <div class="container mx-auto p-6">
        <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
            <h2 class="text-2xl font-bold mb-6">Checkout</h2>
            
            <form method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Shipping Address</label>
                    <textarea name="address" rows="3" required 
                              class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-blue-500"
                              placeholder="Enter your full shipping address"></textarea>
                </div>
                
                <div class="mb-6">
                    <label class="block text-gray-700 font-semibold mb-2">Payment Method</label>
                    <select name="payment_mode" required 
                            class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-blue-500">
                        <?php while($pm = mysqli_fetch_assoc($paymentOptions)): ?>
                            <option value="<?php echo $pm['id']; ?>"><?php echo htmlspecialchars($pm['mode_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <button type="submit" 
                        class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-semibold">
                    Place Order
                </button>
            </form>
        </div>
    </div>
</body>
</html>