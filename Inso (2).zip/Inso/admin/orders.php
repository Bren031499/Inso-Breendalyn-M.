<?php
session_start();
require_once '../config/mysqli_connect.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $sql = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $new_status, $order_id);
    mysqli_stmt_execute($stmt);
    
    header('Location: orders.php');
    exit();
}

// Handle delete order
if (isset($_GET['delete'])) {
    $order_id = (int)$_GET['delete'];
    $sql = "DELETE FROM orders WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    header('Location: orders.php');
    exit();
}


$orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY created_at DESC");


$status_counts = [];
$status_query = mysqli_query($conn, "SELECT status, COUNT(*) as count FROM orders GROUP BY status");
while($row = mysqli_fetch_assoc($status_query)) {
    $status_counts[$row['status']] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Earthen Style Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f5efe8;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #2d1810 0%, #3d2317 100%);
        }
        
        .nav-item {
            transition: all 0.2s ease;
        }
        
        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        
        .nav-item.active {
            background: rgba(160, 82, 45, 0.3);
            border-left: 3px solid #A0522D;
        }
        
        .btn-logout {
            transition: all 0.2s ease;
        }
        
        .btn-logout:hover {
            background: #dc2626;
            border-color: #dc2626;
        }
        
        .table-row {
            transition: all 0.2s ease;
        }
        
        .table-row:hover {
            background: #faf6f0;
        }
        
        .status-badge {
            transition: all 0.2s ease;
        }
        
        .status-badge:hover {
            transform: scale(1.05);
        }
        
        .status-select {
            transition: all 0.2s ease;
        }
        
        .status-select:focus {
            outline: none;
            border-color: #A0522D;
            ring: 2px solid rgba(160, 82, 45, 0.2);
        }
        
        .modal {
            transition: all 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .orders-content {
            animation: fadeIn 0.4s ease-out;
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
  
    <aside class="sidebar w-72 flex flex-col shadow-xl">
        <div class="p-6 border-b border-amber-800/30">
            <div class="flex items-center gap-3">
                <div class="text-3xl">👜</div>
                <div>
                    <h1 class="text-xl font-bold text-white serif">EARTHEN STYLE</h1>
                    <p class="text-amber-300 text-xs">Admin Panel</p>
                </div>
            </div>
        </div>
        
        <nav class="flex-1 py-6">
            <div class="px-4 space-y-1">
                <a href="dashboard.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tachometer-alt w-5"></i>
                    <span>Dashboard</span>
                </a>
                <a href="products.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-box w-5"></i>
                    <span>Products</span>
                </a>
                <a href="brands.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tag w-5"></i>
                    <span>Brands</span>
                </a>
                <a href="orders.php" class="nav-item active flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Orders</span>
                </a>
                <a href="customers.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-users w-5"></i>
                    <span>Customers</span>
                </a>
            </div>
        </nav>
        
        <div class="p-4 border-t border-amber-800/30">
            <div class="bg-amber-900/30 rounded-lg p-4 mb-4">
                <div class="flex items-center gap-2 text-amber-200 text-sm">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo $_SESSION['admin_fullname']; ?></span>
                </div>
                <div class="flex items-center gap-2 text-amber-300 text-xs mt-1">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>
            <a href="logout.php" class="btn-logout flex items-center justify-center gap-2 w-full px-4 py-2 bg-amber-800/50 rounded-lg text-amber-200 hover:text-white transition">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    

    <main class="flex-1 overflow-y-auto">
       
        <div class="bg-white border-b border-amber-100 px-8 py-5">
            <div>
                <h2 class="text-2xl font-bold text-gray-800 serif">Orders</h2>
                <p class="text-gray-500 text-sm mt-1">Manage and track customer orders</p>
            </div>
        </div>
        
        <div class="p-8 orders-content">
           
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
                <div class="bg-white rounded-xl p-4 shadow-sm border-l-4 border-yellow-500">
                    <p class="text-xs text-gray-500">Pending</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $status_counts['pending'] ?? 0; ?></p>
                </div>
                <div class="bg-white rounded-xl p-4 shadow-sm border-l-4 border-green-500">
                    <p class="text-xs text-gray-500">Approved</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $status_counts['approved'] ?? 0; ?></p>
                </div>
                <div class="bg-white rounded-xl p-4 shadow-sm border-l-4 border-red-500">
                    <p class="text-xs text-gray-500">Disapproved</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $status_counts['disapproved'] ?? 0; ?></p>
                </div>
                <div class="bg-white rounded-xl p-4 shadow-sm border-l-4 border-gray-500">
                    <p class="text-xs text-gray-500">Cancelled</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $status_counts['cancelled'] ?? 0; ?></p>
                </div>
                <div class="bg-white rounded-xl p-4 shadow-sm border-l-4 border-blue-500">
                    <p class="text-xs text-gray-500">Delivered</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $status_counts['delivered'] ?? 0; ?></p>
                </div>
            </div>
            
      
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Order #</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Customer</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Contact</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Total</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Date</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($orders && mysqli_num_rows($orders) > 0): ?>
                                <?php while($order = mysqli_fetch_assoc($orders)): ?>
                                <tr class="border-b table-row">
                                    <td class="px-6 py-4 font-semibold text-gray-800">#<?php echo $order['order_number']; ?></td>
                                    <td class="px-6 py-4">
                                        <div>
                                            <p class="font-medium text-gray-800"><?php echo htmlspecialchars($order['customer_name']); ?></p>
                                            <p class="text-xs text-gray-500"><?php echo htmlspecialchars($order['customer_email']); ?></p>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-gray-600"><?php echo htmlspecialchars($order['customer_phone'] ?? 'N/A'); ?></td>
                                    <td class="px-6 py-4 font-bold text-amber-600">₱<?php echo number_format($order['total_amount'], 2); ?></td>
                                    <td class="px-6 py-4">
                                        <form method="POST" class="status-update-form">
                                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                            <input type="hidden" name="update_status" value="1">
                                            <select name="status" onchange="this.form.submit()" 
                                                    class="status-select px-3 py-1 rounded-full text-xs font-semibold border-0 cursor-pointer
                                                        <?php echo $order['status'] == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                                               ($order['status'] == 'approved' ? 'bg-green-100 text-green-800' :
                                                               ($order['status'] == 'delivered' ? 'bg-blue-100 text-blue-800' : 
                                                               ($order['status'] == 'cancelled' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'))); ?>">
                                                <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="approved" <?php echo $order['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                                <option value="disapproved" <?php echo $order['status'] == 'disapproved' ? 'selected' : ''; ?>>Disapproved</option>
                                                <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                                <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                            </select>
                                        </form>
                                    </td>
                                    <td class="px-6 py-4 text-gray-500 text-sm"><?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></td>
                                    <td class="px-6 py-4">
                                        <button onclick="viewOrderDetails(<?php echo htmlspecialchars(json_encode($order)); ?>)" 
                                                class="text-blue-600 hover:text-blue-800 mr-3">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <a href="?delete=<?php echo $order['id']; ?>" 
                                           onclick="return confirm('Are you sure you want to delete this order?')"
                                           class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                <tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                                        <i class="fas fa-shopping-cart text-4xl mb-2"></i>
                                        <p>No orders found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    
 
    <div id="orderModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto modal">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-2xl font-bold serif">Order Details</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>
                
                <div id="orderDetails" class="space-y-4">
                    
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function viewOrderDetails(order) {
            const modal = document.getElementById('orderModal');
            const detailsDiv = document.getElementById('orderDetails');
            
            detailsDiv.innerHTML = `
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="font-semibold text-gray-800 mb-2">Order Information</h4>
                    <div class="grid grid-cols-2 gap-3 text-sm">
                        <div>
                            <p class="text-gray-500">Order Number:</p>
                            <p class="font-semibold">#${order.order_number}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Order Date:</p>
                            <p class="font-semibold">${new Date(order.created_at).toLocaleString()}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Order Status:</p>
                            <p class="font-semibold capitalize">${order.status}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Payment Method:</p>
                            <p class="font-semibold">${order.payment_method || 'N/A'}</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="font-semibold text-gray-800 mb-2">Customer Information</h4>
                    <div class="grid grid-cols-2 gap-3 text-sm">
                        <div>
                            <p class="text-gray-500">Full Name:</p>
                            <p class="font-semibold">${escapeHtml(order.customer_name)}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Email:</p>
                            <p class="font-semibold">${escapeHtml(order.customer_email)}</p>
                        </div>
                        <div>
                            <p class="text-gray-500">Phone:</p>
                            <p class="font-semibold">${order.customer_phone || 'N/A'}</p>
                        </div>
                        <div class="col-span-2">
                            <p class="text-gray-500">Address:</p>
                            <p class="font-semibold">${escapeHtml(order.customer_address || 'N/A')}</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="font-semibold text-gray-800 mb-2">Order Summary</h4>
                    <div class="flex justify-between items-center pt-2 border-t border-gray-200">
                        <span class="text-gray-600">Total Amount:</span>
                        <span class="text-2xl font-bold text-amber-600">₱${parseFloat(order.total_amount).toFixed(2)}</span>
                    </div>
                    ${order.notes ? `
                    <div class="mt-3 pt-2 border-t border-gray-200">
                        <p class="text-gray-500 text-sm">Notes:</p>
                        <p class="text-sm">${escapeHtml(order.notes)}</p>
                    </div>
                    ` : ''}
                </div>
            `;
            
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function closeModal() {
            const modal = document.getElementById('orderModal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
        
    \
        document.getElementById('orderModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    </script>
</body>
</html>