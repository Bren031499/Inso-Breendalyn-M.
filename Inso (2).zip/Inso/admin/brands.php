<?php
session_start();
require_once '../config/mysqli_connect.php';


if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch($_POST['action']) {
            case 'add':
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $description = mysqli_real_escape_string($conn, $_POST['description']);
                $status = $_POST['status'];
                
                $sql = "INSERT INTO brands (name, description, status) VALUES (?, ?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "sss", $name, $description, $status);
                mysqli_stmt_execute($stmt);
                break;
                
            case 'edit':
                $id = $_POST['id'];
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $description = mysqli_real_escape_string($conn, $_POST['description']);
                $status = $_POST['status'];
                
                $sql = "UPDATE brands SET name=?, description=?, status=? WHERE id=?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "sssi", $name, $description, $status, $id);
                mysqli_stmt_execute($stmt);
                break;
                
            case 'delete':
                $id = $_POST['id'];
                $sql = "DELETE FROM brands WHERE id=?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                break;
        }
        header('Location: brands.php');
        exit();
    }
}

$brands = mysqli_query($conn, "SELECT * FROM brands ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brands - Earthen Style Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { font-family: 'Inter', sans-serif; }
        .serif { font-family: 'Playfair Display', serif; }
        body { background: #f5efe8; }
        .sidebar { background: linear-gradient(180deg, #2d1810 0%, #3d2317 100%); }
        .nav-item { transition: all 0.2s ease; }
        .nav-item:hover { background: rgba(255, 255, 255, 0.1); transform: translateX(5px); }
        .nav-item.active { background: rgba(160, 82, 45, 0.3); border-left: 3px solid #A0522D; }
        .btn-primary { background: #A0522D; transition: all 0.2s ease; }
        .btn-primary:hover { background: #8B4513; transform: translateY(-1px); }
        .btn-secondary { background: #6B7280; transition: all 0.2s ease; }
        .btn-secondary:hover { background: #4B5563; }
        .table-row { transition: all 0.2s ease; }
        .table-row:hover { background: #faf6f0; }
        .modal { transition: all 0.3s ease; }
        .input-field {
            transition: all 0.2s ease;
            border: 1px solid #e5e7eb;
        }
        .input-field:focus {
            outline: none;
            border-color: #A0522D;
            ring: 2px solid rgba(160, 82, 45, 0.2);
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    <aside class="sidebar w-72 flex flex-col shadow-xl">
        <div class="p-6 border-b border-amber-800/30">
            <div class="flex items-center gap-3">
                <div class="text-3xl">👜</div>
                <div>
                    <h1 class="text-xl font-bold text-white serif">EARTHEN STYLE</h1>
                    <p class="text-amber-300 text-xs">Admin Panel</p>
                </div>
            </div>
        </div>
        <nav class="flex-1 py-6">
            <div class="px-4 space-y-1">
                <a href="dashboard.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tachometer-alt w-5"></i><span>Dashboard</span>
                </a>
                <a href="products.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-box w-5"></i><span>Products</span>
                </a>
                <a href="brands.php" class="nav-item active flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tag w-5"></i><span>Brands</span>
                </a>
                <a href="orders.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-shopping-cart w-5"></i><span>Orders</span>
                </a>
                <a href="customers.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-users w-5"></i><span>Customers</span>
                </a>
            </div>
        </nav>
        <div class="p-4 border-t border-amber-800/30">
            <div class="bg-amber-900/30 rounded-lg p-4 mb-4">
                <div class="flex items-center gap-2 text-amber-200 text-sm">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo $_SESSION['admin_fullname']; ?></span>
                </div>
                <div class="flex items-center gap-2 text-amber-300 text-xs mt-1">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>
            <a href="logout.php" class="flex items-center justify-center gap-2 w-full px-4 py-2 bg-amber-800/50 rounded-lg text-amber-200 hover:text-white transition">
                <i class="fas fa-sign-out-alt"></i><span>Logout</span>
            </a>
        </div>
    </aside>
    
    <main class="flex-1 overflow-y-auto">
        <div class="bg-white border-b border-amber-100 px-8 py-5">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800 serif">Brands</h2>
                    <p class="text-gray-500 text-sm mt-1">Manage your product brands</p>
                </div>
                <button onclick="openBrandModal()" class="bg-amber-600 hover:bg-amber-700 text-white px-6 py-2 rounded-lg font-semibold transition flex items-center gap-2">
                    <i class="fas fa-plus"></i> Add Brand
                </button>
            </div>
        </div>
        
        <div class="p-8">
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Brand Name</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Description</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Created</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($brand = mysqli_fetch_assoc($brands)): ?>
                            <tr class="border-b table-row">
                                <td class="px-6 py-4 font-medium text-gray-800"><?php echo htmlspecialchars($brand['name']); ?></td>
                                <td class="px-6 py-4 text-gray-600"><?php echo htmlspecialchars(substr($brand['description'] ?? '', 0, 50)); ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded-full text-xs font-semibold <?php echo $brand['status'] == 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                        <?php echo ucfirst($brand['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-gray-500 text-sm"><?php echo date('M d, Y', strtotime($brand['created_at'])); ?></td>
                                <td class="px-6 py-4">
                                    <button onclick='editBrand(<?php echo json_encode($brand); ?>)' class="text-blue-600 hover:text-blue-800 mr-3">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="deleteBrand(<?php echo $brand['id']; ?>)" class="text-red-600 hover:text-red-800">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    
    
    <div id="brandModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white rounded-2xl max-w-md w-full modal">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-2xl font-bold serif" id="modalTitle">Add Brand</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>
                
                <form method="POST" id="brandForm">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="id" id="brandId">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Brand Name</label>
                            <input type="text" name="name" id="brandName" required 
                                   class="input-field w-full rounded-lg px-4 py-2 focus:outline-none">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Description</label>
                            <textarea name="description" id="brandDescription" rows="3" 
                                      class="input-field w-full rounded-lg px-4 py-2 focus:outline-none"></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Status</label>
                            <select name="status" id="brandStatus" class="input-field w-full rounded-lg px-4 py-2">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex gap-3 mt-6">
                        <button type="submit" class="btn-primary flex-1 text-white font-semibold py-2 rounded-lg">
                            Save Brand
                        </button>
                        <button type="button" onclick="closeModal()" class="btn-secondary flex-1 text-white font-semibold py-2 rounded-lg">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        const modal = document.getElementById('brandModal');
        
        function openBrandModal() {
            document.getElementById('modalTitle').innerText = 'Add Brand';
            document.getElementById('formAction').value = 'add';
            document.getElementById('brandForm').reset();
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function editBrand(brand) {
            document.getElementById('modalTitle').innerText = 'Edit Brand';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('brandId').value = brand.id;
            document.getElementById('brandName').value = brand.name;
            document.getElementById('brandDescription').value = brand.description || '';
            document.getElementById('brandStatus').value = brand.status;
            
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function deleteBrand(id) {
            if (confirm('Are you sure you want to delete this brand? This may affect associated products.')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function closeModal() {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
        
     
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    </script>
</body>
</html>