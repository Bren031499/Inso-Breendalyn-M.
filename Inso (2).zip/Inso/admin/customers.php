<?php
session_start();
require_once '../config/mysqli_connect.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

if (isset($_GET['delete'])) {
    $customer_id = (int)$_GET['delete'];
    $sql = "DELETE FROM customers WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $customer_id);
    mysqli_stmt_execute($stmt);
    header('Location: customers.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch($_POST['action']) {
            case 'add':
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $phone = mysqli_real_escape_string($conn, $_POST['phone']);
                $address = mysqli_real_escape_string($conn, $_POST['address']);
                $status = $_POST['status'];
                
                $sql = "INSERT INTO customers (name, email, phone, address, status) VALUES (?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "sssss", $name, $email, $phone, $address, $status);
                mysqli_stmt_execute($stmt);
                break;
                
            case 'edit':
                $id = $_POST['id'];
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $phone = mysqli_real_escape_string($conn, $_POST['phone']);
                $address = mysqli_real_escape_string($conn, $_POST['address']);
                $status = $_POST['status'];
                
                $sql = "UPDATE customers SET name=?, email=?, phone=?, address=?, status=? WHERE id=?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "sssssi", $name, $email, $phone, $address, $status, $id);
                mysqli_stmt_execute($stmt);
                break;
        }
        header('Location: customers.php');
        exit();
    }
}

$table_check = mysqli_query($conn, "SHOW TABLES LIKE 'customers'");
if(mysqli_num_rows($table_check) == 0) {
    $create_table = "CREATE TABLE IF NOT EXISTS customers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(20),
        address TEXT,
        total_orders INT DEFAULT 0,
        total_spent DECIMAL(10,2) DEFAULT 0.00,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    mysqli_query($conn, $create_table);
}


$customers = mysqli_query($conn, "SELECT * FROM customers ORDER BY created_at DESC");


$total_customers = mysqli_num_rows($customers);
$active_customers = mysqli_query($conn, "SELECT COUNT(*) as count FROM customers WHERE status = 'active'");
$active_count = mysqli_fetch_assoc($active_customers)['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers - Earthen Style Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f5efe8;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #2d1810 0%, #3d2317 100%);
        }
        
        .nav-item {
            transition: all 0.2s ease;
        }
        
        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        
        .nav-item.active {
            background: rgba(160, 82, 45, 0.3);
            border-left: 3px solid #A0522D;
        }
        
        .btn-logout {
            transition: all 0.2s ease;
        }
        
        .btn-logout:hover {
            background: #dc2626;
            border-color: #dc2626;
        }
        
        .table-row {
            transition: all 0.2s ease;
        }
        
        .table-row:hover {
            background: #faf6f0;
        }
        
        .btn-primary {
            background: #A0522D;
            transition: all 0.2s ease;
        }
        
        .btn-primary:hover {
            background: #8B4513;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #6B7280;
            transition: all 0.2s ease;
        }
        
        .btn-secondary:hover {
            background: #4B5563;
        }
        
        .modal {
            transition: all 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .customers-content {
            animation: fadeIn 0.4s ease-out;
        }
        
        .input-field {
            transition: all 0.2s ease;
            border: 1px solid #e5e7eb;
        }
        
        .input-field:focus {
            outline: none;
            border-color: #A0522D;
            ring: 2px solid rgba(160, 82, 45, 0.2);
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    
    <aside class="sidebar w-72 flex flex-col shadow-xl">
        <div class="p-6 border-b border-amber-800/30">
            <div class="flex items-center gap-3">
                <div class="text-3xl">👜</div>
                <div>
                    <h1 class="text-xl font-bold text-white serif">EARTHEN STYLE</h1>
                    <p class="text-amber-300 text-xs">Admin Panel</p>
                </div>
            </div>
        </div>
        
        <nav class="flex-1 py-6">
            <div class="px-4 space-y-1">
                <a href="dashboard.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tachometer-alt w-5"></i>
                    <span>Dashboard</span>
                </a>
                <a href="products.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-box w-5"></i>
                    <span>Products</span>
                </a>
                <a href="brands.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tag w-5"></i>
                    <span>Brands</span>
                </a>
                <a href="orders.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Orders</span>
                </a>
                <a href="customers.php" class="nav-item active flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-users w-5"></i>
                    <span>Customers</span>
                </a>
            </div>
        </nav>
        
        <div class="p-4 border-t border-amber-800/30">
            <div class="bg-amber-900/30 rounded-lg p-4 mb-4">
                <div class="flex items-center gap-2 text-amber-200 text-sm">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo $_SESSION['admin_fullname']; ?></span>
                </div>
                <div class="flex items-center gap-2 text-amber-300 text-xs mt-1">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>
            <a href="logout.php" class="btn-logout flex items-center justify-center gap-2 w-full px-4 py-2 bg-amber-800/50 rounded-lg text-amber-200 hover:text-white transition">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    

    <main class="flex-1 overflow-y-auto">
     
        <div class="bg-white border-b border-amber-100 px-8 py-5">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800 serif">Customers</h2>
                    <p class="text-gray-500 text-sm mt-1">Manage your customer database</p>
                </div>
                <button onclick="openCustomerModal()" class="bg-amber-600 hover:bg-amber-700 text-white px-6 py-2 rounded-lg font-semibold transition flex items-center gap-2">
                    <i class="fas fa-plus"></i> Add Customer
                </button>
            </div>
        </div>
        
        <div class="p-8 customers-content">
      
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white rounded-xl p-6 shadow-sm border-l-4 border-amber-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm">Total Customers</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo $total_customers; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-users text-amber-600 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 shadow-sm border-l-4 border-green-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm">Active Customers</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo $active_count; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user-check text-green-600 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 shadow-sm border-l-4 border-blue-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm">Total Orders</p>
                            <p class="text-3xl font-bold text-gray-800">
                                <?php 
                                    $total_orders = mysqli_query($conn, "SELECT COUNT(*) as count FROM orders");
                                    echo mysqli_fetch_assoc($total_orders)['count'];
                                ?>
                            </p>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-shopping-cart text-blue-600 text-xl"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Customer</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Contact</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Address</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Orders</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Joined</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($customers && mysqli_num_rows($customers) > 0): ?>
                                <?php while($customer = mysqli_fetch_assoc($customers)): ?>
                                <tr class="border-b table-row">
                                    <td class="px-6 py-4">
                                        <div>
                                            <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($customer['name']); ?></p>
                                            <p class="text-xs text-gray-500">ID: #<?php echo $customer['id']; ?></p>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div>
                                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($customer['email']); ?></p>
                                            <p class="text-xs text-gray-400"><?php echo htmlspecialchars($customer['phone'] ?? 'No phone'); ?></p>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600 max-w-xs">
                                        <?php echo htmlspecialchars(substr($customer['address'] ?? '', 0, 50)); ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-semibold">
                                            <?php echo $customer['total_orders'] ?? 0; ?> orders
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 rounded-full text-xs font-semibold <?php echo $customer['status'] == 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo ucfirst($customer['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-500">
                                        <?php echo date('M d, Y', strtotime($customer['created_at'])); ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <button onclick='editCustomer(<?php echo htmlspecialchars(json_encode($customer)); ?>)' 
                                                class="text-blue-600 hover:text-blue-800 mr-3">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="?delete=<?php echo $customer['id']; ?>" 
                                           onclick="return confirm('Are you sure you want to delete this customer?')"
                                           class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                                        <i class="fas fa-users text-4xl mb-2"></i>
                                        <p>No customers found. Click "Add Customer" to get started.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    
    <div id="customerModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white rounded-2xl max-w-md w-full modal">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-2xl font-bold serif" id="modalTitle">Add Customer</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>
                
                <form method="POST" id="customerForm">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="id" id="customerId">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Full Name</label>
                            <input type="text" name="name" id="customerName" required 
                                   class="input-field w-full rounded-lg px-4 py-2 focus:outline-none">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Email Address</label>
                            <input type="email" name="email" id="customerEmail" required 
                                   class="input-field w-full rounded-lg px-4 py-2 focus:outline-none">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Phone Number</label>
                            <input type="tel" name="phone" id="customerPhone" 
                                   class="input-field w-full rounded-lg px-4 py-2 focus:outline-none">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Address</label>
                            <textarea name="address" id="customerAddress" rows="3" 
                                      class="input-field w-full rounded-lg px-4 py-2 focus:outline-none"></textarea>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Status</label>
                            <select name="status" id="customerStatus" 
                                    class="input-field w-full rounded-lg px-4 py-2 focus:outline-none">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex gap-3 mt-6">
                        <button type="submit" class="btn-primary flex-1 text-white font-semibold py-2 rounded-lg">
                            Save Customer
                        </button>
                        <button type="button" onclick="closeModal()" class="btn-secondary flex-1 text-white font-semibold py-2 rounded-lg">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        const modal = document.getElementById('customerModal');
        
        function openCustomerModal() {
            document.getElementById('modalTitle').innerText = 'Add Customer';
            document.getElementById('formAction').value = 'add';
            document.getElementById('customerForm').reset();
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function editCustomer(customer) {
            document.getElementById('modalTitle').innerText = 'Edit Customer';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('customerId').value = customer.id;
            document.getElementById('customerName').value = customer.name;
            document.getElementById('customerEmail').value = customer.email;
            document.getElementById('customerPhone').value = customer.phone || '';
            document.getElementById('customerAddress').value = customer.address || '';
            document.getElementById('customerStatus').value = customer.status;
            
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function closeModal() {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
       
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    </script>
</body>
</html>