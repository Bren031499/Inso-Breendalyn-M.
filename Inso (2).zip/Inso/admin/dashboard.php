<?php
session_start();
require_once '../config/mysqli_connect.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}


$stats = [];

$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM products WHERE status = 'active'");
$stats['total_products'] = mysqli_fetch_assoc($result)['total'] ?? 0;


$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders");
$stats['total_orders'] = mysqli_fetch_assoc($result)['total'] ?? 0;


$result = mysqli_query($conn, "SELECT COUNT(DISTINCT customer_email) as total FROM orders");
$stats['total_customers'] = mysqli_fetch_assoc($result)['total'] ?? 0;


$result = mysqli_query($conn, "SELECT SUM(total_amount) as total FROM orders WHERE status IN ('approved', 'delivered')");
$stats['total_revenue'] = mysqli_fetch_assoc($result)['total'] ?? 0;

$recent_orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY created_at DESC LIMIT 5");


$low_stock = mysqli_query($conn, "SELECT * FROM products WHERE stock_quantity < 10 AND status = 'active' ORDER BY stock_quantity ASC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Earthen Style Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f5efe8;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #2d1810 0%, #3d2317 100%);
        }
        
        .nav-item {
            transition: all 0.2s ease;
        }
        
        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        
        .nav-item.active {
            background: rgba(160, 82, 45, 0.3);
            border-left: 3px solid #A0522D;
        }
        
        .stat-card {
            transition: all 0.3s ease;
            border: 1px solid #e8ddd0;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(93, 58, 26, 0.1);
            border-color: #d4a574;
        }
        
        .btn-logout {
            transition: all 0.2s ease;
        }
        
        .btn-logout:hover {
            background: #dc2626;
            border-color: #dc2626;
        }
        
        .order-status {
            transition: all 0.2s ease;
        }
        
        .order-status:hover {
            transform: scale(1.05);
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .dashboard-content {
            animation: fadeIn 0.4s ease-out;
        }
        
        .table-row {
            transition: all 0.2s ease;
        }
        
        .table-row:hover {
            background: #faf6f0;
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">

    <aside class="sidebar w-72 flex flex-col shadow-xl">
        <div class="p-6 border-b border-amber-800/30">
            <div class="flex items-center gap-3">
                <div class="text-3xl">👜</div>
                <div>
                    <h1 class="text-xl font-bold text-white serif">EARTHEN STYLE</h1>
                    <p class="text-amber-300 text-xs">Admin Panel</p>
                </div>
            </div>
        </div>
        
        <nav class="flex-1 py-6">
            <div class="px-4 space-y-1">
                <a href="dashboard.php" class="nav-item active flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tachometer-alt w-5"></i>
                    <span>Dashboard</span>
                </a>
                <a href="products.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-box w-5"></i>
                    <span>Products</span>
                </a>
                <a href="brands.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tag w-5"></i>
                    <span>Brands</span>
                </a>
                <a href="orders.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Orders</span>
                </a>
                <a href="customers.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-users w-5"></i>
                    <span>Customers</span>
                </a>
            </div>
        </nav>
        
        <div class="p-4 border-t border-amber-800/30">
            <div class="bg-amber-900/30 rounded-lg p-4 mb-4">
                <div class="flex items-center gap-2 text-amber-200 text-sm">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo $_SESSION['admin_fullname']; ?></span>
                </div>
                <div class="flex items-center gap-2 text-amber-300 text-xs mt-1">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>
            <a href="logout.php" class="btn-logout flex items-center justify-center gap-2 w-full px-4 py-2 bg-amber-800/50 rounded-lg text-amber-200 hover:text-white transition">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    
    
    <main class="flex-1 overflow-y-auto">
        
        <div class="bg-white border-b border-amber-100 px-8 py-5">
            <div>
                <h2 class="text-2xl font-bold text-gray-800 serif">Dashboard</h2>
                <p class="text-gray-500 text-sm mt-1">Welcome back, <?php echo $_SESSION['admin_fullname']; ?>! Here's what's happening with your store today.</p>
            </div>
        </div>
        
        <div class="p-8 dashboard-content">
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="stat-card bg-white rounded-2xl p-6 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm mb-1">Total Orders</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_orders']; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-shopping-cart text-amber-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-3 text-xs text-green-600">
                        <i class="fas fa-arrow-up"></i> +12% from last month
                    </div>
                </div>
                
                <div class="stat-card bg-white rounded-2xl p-6 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm mb-1">Total Customers</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_customers']; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-3 text-xs text-green-600">
                        <i class="fas fa-arrow-up"></i> +5 new this week
                    </div>
                </div>
                
                <div class="stat-card bg-white rounded-2xl p-6 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm mb-1">Total Products</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_products']; ?></p>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-box text-green-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-3 text-xs text-amber-600">
                        <i class="fas fa-info-circle"></i> <?php 
                            $low_stock_count = mysqli_num_rows($low_stock);
                            echo $low_stock_count . " products low in stock";
                        ?>
                    </div>
                </div>
                
                <div class="stat-card bg-white rounded-2xl p-6 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm mb-1">Total Revenue</p>
                            <p class="text-3xl font-bold text-amber-700">₱<?php echo number_format($stats['total_revenue'], 2); ?></p>
                        </div>
                        <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-peso-sign text-yellow-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-3 text-xs text-amber-600">
                        <i class="fas fa-chart-line"></i> Monthly revenue target: ₱50,000
                    </div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
                <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                        <h3 class="font-bold text-gray-800">
                            <i class="fas fa-clock text-amber-600 mr-2"></i> Recent Orders
                        </h3>
                        <a href="orders.php" class="text-amber-600 text-sm hover:text-amber-700">View All →</a>
                    </div>
                    <div class="divide-y divide-gray-100">
                        <?php if(mysqli_num_rows($recent_orders) > 0): ?>
                            <?php while($order = mysqli_fetch_assoc($recent_orders)): ?>
                            <div class="px-6 py-3 table-row">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <p class="font-semibold text-gray-800">#<?php echo $order['order_number']; ?></p>
                                        <p class="text-xs text-gray-500"><?php echo htmlspecialchars($order['customer_name']); ?></p>
                                    </div>
                                    <div class="text-right">
                                        <p class="font-bold text-amber-600">₱<?php echo number_format($order['total_amount'], 2); ?></p>
                                        <span class="order-status inline-block px-2 py-1 rounded-full text-xs font-semibold 
                                            <?php echo $order['status'] == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                                   ($order['status'] == 'approved' ? 'bg-green-100 text-green-800' :
                                                   ($order['status'] == 'delivered' ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800')); ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="px-6 py-8 text-center text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-2"></i>
                                <p>No orders yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                
                <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                        <h3 class="font-bold text-gray-800">
                            <i class="fas fa-exclamation-triangle text-orange-500 mr-2"></i> Low Stock Alert
                        </h3>
                        <a href="products.php" class="text-amber-600 text-sm hover:text-amber-700">Manage Stock →</a>
                    </div>
                    <div class="divide-y divide-gray-100">
                        <?php if(mysqli_num_rows($low_stock) > 0): ?>
                            <?php while($product = mysqli_fetch_assoc($low_stock)): ?>
                            <div class="px-6 py-3 table-row">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($product['name']); ?></p>
                                        <p class="text-xs text-gray-500">Stock: <?php echo $product['stock_quantity']; ?> units left</p>
                                    </div>
                                    <a href="products.php?edit=<?php echo $product['id']; ?>" class="text-amber-600 hover:text-amber-700">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="px-6 py-8 text-center text-gray-500">
                                <i class="fas fa-check-circle text-green-500 text-4xl mb-2"></i>
                                <p>All products have sufficient stock!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>