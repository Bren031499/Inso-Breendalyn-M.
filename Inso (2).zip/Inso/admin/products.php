<?php
session_start();
require_once '../config/mysqli_connect.php';


if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch($_POST['action']) {
            case 'add':
                $brand_id = $_POST['brand_id'] ?? null;
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $description = mysqli_real_escape_string($conn, $_POST['description']);
                $price = $_POST['price'];
                $category = mysqli_real_escape_string($conn, $_POST['category']);
                $size_options = mysqli_real_escape_string($conn, $_POST['size_options']);
                $stock_quantity = $_POST['stock_quantity'];
                $status = $_POST['status'];
                
                // Handle image upload
                $image = '';
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $target_dir = "../uploads/products/";
                    if (!file_exists($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    $image = $target_dir . time() . "_" . basename($_FILES['image']['name']);
                    move_uploaded_file($_FILES['image']['tmp_name'], $image);
                }
                
                $sql = "INSERT INTO products (brand_id, name, description, price, category, size_options, stock_quantity, image, status) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "issdssiss", $brand_id, $name, $description, $price, $category, $size_options, $stock_quantity, $image, $status);
                mysqli_stmt_execute($stmt);
                break;
                
            case 'edit':
                $id = $_POST['id'];
                $brand_id = $_POST['brand_id'] ?? null;
                $name = mysqli_real_escape_string($conn, $_POST['name']);
                $description = mysqli_real_escape_string($conn, $_POST['description']);
                $price = $_POST['price'];
                $category = mysqli_real_escape_string($conn, $_POST['category']);
                $size_options = mysqli_real_escape_string($conn, $_POST['size_options']);
                $stock_quantity = $_POST['stock_quantity'];
                $status = $_POST['status'];
                
                $sql = "UPDATE products SET brand_id=?, name=?, description=?, price=?, category=?, size_options=?, stock_quantity=?, status=? WHERE id=?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "issdssisi", $brand_id, $name, $description, $price, $category, $size_options, $stock_quantity, $status, $id);
                mysqli_stmt_execute($stmt);
                break;
                
            case 'delete':
                $id = $_POST['id'];
                $sql = "DELETE FROM products WHERE id=?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                break;
        }
        header('Location: products.php');
        exit();
    }
}


$products = mysqli_query($conn, "
    SELECT p.*, b.name as brand_name 
    FROM products p 
    LEFT JOIN brands b ON p.brand_id = b.id 
    ORDER BY p.created_at DESC
");


$brands = mysqli_query($conn, "SELECT * FROM brands WHERE status = 'active'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Earthen Style Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f5efe8;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #2d1810 0%, #3d2317 100%);
        }
        
        .nav-item {
            transition: all 0.2s ease;
        }
        
        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        
        .nav-item.active {
            background: rgba(160, 82, 45, 0.3);
            border-left: 3px solid #A0522D;
        }
        
        .btn-logout {
            transition: all 0.2s ease;
        }
        
        .btn-logout:hover {
            background: #dc2626;
            border-color: #dc2626;
        }
        
        .table-row {
            transition: all 0.2s ease;
        }
        
        .table-row:hover {
            background: #faf6f0;
        }
        
        .modal {
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #A0522D;
            transition: all 0.2s ease;
        }
        
        .btn-primary:hover {
            background: #8B4513;
            transform: translateY(-1px);
        }
        
        .btn-secondary {
            background: #6B7280;
            transition: all 0.2s ease;
        }
        
        .btn-secondary:hover {
            background: #4B5563;
        }
    </style>
</head>
<body class="flex h-screen overflow-hidden">
    
    <aside class="sidebar w-72 flex flex-col shadow-xl">
        <div class="p-6 border-b border-amber-800/30">
            <div class="flex items-center gap-3">
                <div class="text-3xl">👜</div>
                <div>
                    <h1 class="text-xl font-bold text-white serif">EARTHEN STYLE</h1>
                    <p class="text-amber-300 text-xs">Admin Panel</p>
                </div>
            </div>
        </div>
        
        <nav class="flex-1 py-6">
            <div class="px-4 space-y-1">
                <a href="dashboard.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tachometer-alt w-5"></i>
                    <span>Dashboard</span>
                </a>
                <a href="products.php" class="nav-item active flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-box w-5"></i>
                    <span>Products</span>
                </a>
                <a href="brands.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-tag w-5"></i>
                    <span>Brands</span>
                </a>
                <a href="orders.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Orders</span>
                </a>
                <a href="customers.php" class="nav-item flex items-center gap-3 px-4 py-3 rounded-lg text-amber-100 hover:text-white transition">
                    <i class="fas fa-users w-5"></i>
                    <span>Customers</span>
                </a>
            </div>
        </nav>
        
        <div class="p-4 border-t border-amber-800/30">
            <div class="bg-amber-900/30 rounded-lg p-4 mb-4">
                <div class="flex items-center gap-2 text-amber-200 text-sm">
                    <i class="fas fa-user-circle"></i>
                    <span><?php echo $_SESSION['admin_fullname']; ?></span>
                </div>
                <div class="flex items-center gap-2 text-amber-300 text-xs mt-1">
                    <i class="fas fa-envelope"></i>
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>
            <a href="logout.php" class="btn-logout flex items-center justify-center gap-2 w-full px-4 py-2 bg-amber-800/50 rounded-lg text-amber-200 hover:text-white transition">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    
    
    <main class="flex-1 overflow-y-auto">
        
        <div class="bg-white border-b border-amber-100 px-8 py-5">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800 serif">Products</h2>
                    <p class="text-gray-500 text-sm mt-1">Manage your product catalog</p>
                </div>
                <button onclick="openProductModal()" class="bg-amber-600 hover:bg-amber-700 text-white px-6 py-2 rounded-lg font-semibold transition flex items-center gap-2">
                    <i class="fas fa-plus"></i> Add Product
                </button>
            </div>
        </div>
        
        <div class="p-8">
            
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Image</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Product Name</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Brand</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Price</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Stock</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                                <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($products && mysqli_num_rows($products) > 0): ?>
                                <?php while($product = mysqli_fetch_assoc($products)): ?>
                                <tr class="border-b table-row">
                                    <td class="px-6 py-4">
                                        <?php if(!empty($product['image']) && file_exists($product['image'])): ?>
                                            <img src="<?php echo $product['image']; ?>" class="w-12 h-12 object-cover rounded-lg">
                                        <?php else: ?>
                                            <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                                                <i class="fas fa-box text-gray-400 text-xl"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 font-medium text-gray-800"><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td class="px-6 py-4 text-gray-600"><?php echo htmlspecialchars($product['brand_name'] ?? 'Unassigned'); ?></td>
                                    <td class="px-6 py-4 text-amber-600 font-bold">₱<?php echo number_format($product['price'], 2); ?></td>
                                    <td class="px-6 py-4">
                                        <span class="<?php echo $product['stock_quantity'] < 10 ? 'text-red-600 font-semibold' : 'text-gray-600'; ?>">
                                            <?php echo $product['stock_quantity']; ?> units
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 rounded-full text-xs font-semibold <?php echo $product['status'] == 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo ucfirst($product['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <button onclick='editProduct(<?php echo json_encode($product); ?>)' class="text-blue-600 hover:text-blue-800 mr-3">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="deleteProduct(<?php echo $product['id']; ?>)" class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-12 text-center text-gray-500">
                                        <i class="fas fa-box-open text-4xl mb-2"></i>
                                        <p>No products found. Click "Add Product" to get started.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    
    
    <div id="productModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-2xl font-bold serif" id="modalTitle">Add Product</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>
                
                <form method="POST" enctype="multipart/form-data" id="productForm">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="id" id="productId">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Product Name</label>
                            <input type="text" name="name" id="productName" required 
                                   class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Brand</label>
                            <select name="brand_id" id="brandId" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500">
                                <option value="">Select Brand</option>
                                <?php while($brand = mysqli_fetch_assoc($brands)): ?>
                                    <option value="<?php echo $brand['id']; ?>"><?php echo htmlspecialchars($brand['name']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Description</label>
                            <textarea name="description" id="description" rows="3" 
                                      class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500"></textarea>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 font-semibold mb-2">Price (₱)</label>
                                <input type="number" step="0.01" name="price" id="price" required 
                                       class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500">
                            </div>
                            <div>
                                <label class="block text-gray-700 font-semibold mb-2">Stock Quantity</label>
                                <input type="number" name="stock_quantity" id="stockQuantity" required 
                                       class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500">
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 font-semibold mb-2">Category</label>
                                <input type="text" name="category" id="category" 
                                       class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500"
                                       placeholder="e.g., Footwear, Bags, Apparel">
                            </div>
                            <div>
                                <label class="block text-gray-700 font-semibold mb-2">Size Options</label>
                                <input type="text" name="size_options" id="sizeOptions" 
                                       class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500"
                                       placeholder="e.g., S-XXL, US 8-12">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Product Image</label>
                            <input type="file" name="image" id="image" accept="image/*" 
                                   class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500">
                            <div id="currentImage" class="mt-2 hidden">
                                <img id="currentImagePreview" src="" class="w-20 h-20 object-cover rounded-lg">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">Status</label>
                            <select name="status" id="status" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-amber-500">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex gap-3 mt-6">
                        <button type="submit" class="btn-primary flex-1 text-white font-semibold py-2 rounded-lg">
                            Save Product
                        </button>
                        <button type="button" onclick="closeModal()" class="btn-secondary flex-1 text-white font-semibold py-2 rounded-lg">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        const modal = document.getElementById('productModal');
        
        function openProductModal() {
            document.getElementById('modalTitle').innerText = 'Add Product';
            document.getElementById('formAction').value = 'add';
            document.getElementById('productForm').reset();
            document.getElementById('currentImage').classList.add('hidden');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function editProduct(product) {
            document.getElementById('modalTitle').innerText = 'Edit Product';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('productId').value = product.id;
            document.getElementById('productName').value = product.name;
            document.getElementById('brandId').value = product.brand_id || '';
            document.getElementById('description').value = product.description || '';
            document.getElementById('price').value = product.price;
            document.getElementById('stockQuantity').value = product.stock_quantity;
            document.getElementById('category').value = product.category || '';
            document.getElementById('sizeOptions').value = product.size_options || '';
            document.getElementById('status').value = product.status;
            
            if (product.image && product.image !== '') {
                document.getElementById('currentImagePreview').src = product.image;
                document.getElementById('currentImage').classList.remove('hidden');
            }
            
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        
        function deleteProduct(id) {
            if (confirm('Are you sure you want to delete this product?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function closeModal() {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
        
    
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    </script>
</body>
</html>