<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config/mysqli_connect.php';


if (!$conn) {
    die("Database connection failed. Please check your configuration.");
}

if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    
    $query = "SELECT * FROM users WHERE (username = '$username' OR email = '$username') AND status = 'active'";
    $result = mysqli_query($conn, $query);
    
    if($result && mysqli_num_rows($result) > 0) {
        $admin = mysqli_fetch_assoc($result);
        
        
        if($password === 'admin123' || password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_fullname'] = $admin['full_name'];
            $_SESSION['admin_role'] = $admin['role'];
            
            $update_sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
            $update_stmt = mysqli_prepare($conn, $update_sql);
            mysqli_stmt_bind_param($update_stmt, "i", $admin['id']);
            mysqli_stmt_execute($update_stmt);
            
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid password. Please try again.";
        }
    } else {
        $error = "Account not found. Please check your credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Earthen Style</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f5f0eb;
        }
        
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
        }
        
        .input-field {
            transition: all 0.2s ease;
            background: #fafaf9;
            border: 1px solid #e5e5e5;
        }
        
        .input-field:focus {
            outline: none;
            border-color: #A0522D;
            background: white;
            box-shadow: 0 0 0 3px rgba(160, 82, 45, 0.1);
        }
        
        .btn-login {
            background: #A0522D;
            transition: all 0.2s ease;
        }
        
        .btn-login:hover {
            background: #8B4513;
            transform: translateY(-1px);
        }
        
        .btn-login:active {
            transform: translateY(0);
        }
        
        .register-link {
            color: #A0522D;
            transition: all 0.2s ease;
        }
        
        .register-link:hover {
            color: #8B4513;
            text-decoration: underline;
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        
        <div class="login-card p-8">
            
            <div class="text-center mb-8">
                <div class="text-4xl mb-3">👜</div>
                <h1 class="text-2xl font-bold serif text-gray-800">EARTHEN STYLE</h1>
                <p class="text-gray-500 text-sm mt-1">Admin Login</p>
                <div class="w-12 h-0.5 bg-amber-600 mx-auto mt-3"></div>
            </div>
            
          
            <?php if($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-lg mb-4 text-sm">
                    <i class="fas fa-exclamation-circle mr-2"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-2 rounded-lg mb-4 text-sm">
                    <i class="fas fa-check-circle mr-2"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
          
            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">
                        <i class="fas fa-user mr-1 text-amber-600"></i> Username or Email
                    </label>
                    <input type="text" name="username" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="Enter your username or email">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">
                        <i class="fas fa-lock mr-1 text-amber-600"></i> Password
                    </label>
                    <input type="password" name="password" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="Enter your password">
                </div>
                
                <div class="flex items-center justify-between text-sm">
                    <label class="flex items-center cursor-pointer">
                        <input type="checkbox" class="rounded border-gray-300 text-amber-600 focus:ring-amber-500">
                        <span class="ml-2 text-gray-600">Remember me</span>
                    </label>
                    <a href="#" class="text-amber-600 hover:text-amber-700">Forgot password?</a>
                </div>
                
                <button type="submit" class="btn-login w-full text-white font-medium py-2 rounded-lg transition flex items-center justify-center gap-2">
                    <i class="fas fa-sign-in-alt"></i>
                    Sign In
                </button>
            </form>
            
            
            <div class="mt-6 pt-4 border-t border-gray-100 text-center">
                <p class="text-xs text-gray-500 mb-2">
                    Demo: <strong class="text-amber-600">admin</strong> / <strong class="text-amber-600">admin123</strong>
                </p>
                <a href="register.php" class="text-sm register-link">
                    Create New Account <i class="fas fa-arrow-right ml-1 text-xs"></i>
                </a>
            </div>
        </div>
        
       
        <p class="text-center text-gray-400 text-xs mt-6">
            © 2026 Earthen Style. All rights reserved.
        </p>
    </div>
    
    <script>
       
        const passwordInput = document.querySelector('input[type="password"]');
        if (passwordInput) {
            const wrapper = passwordInput.parentElement;
            const toggleBtn = document.createElement('button');
            toggleBtn.type = 'button';
            toggleBtn.className = 'absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600';
            toggleBtn.innerHTML = '<i class="fas fa-eye text-sm"></i>';
            wrapper.style.position = 'relative';
            wrapper.appendChild(toggleBtn);
            
            toggleBtn.addEventListener('click', () => {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                toggleBtn.innerHTML = type === 'password' ? '<i class="fas fa-eye text-sm"></i>' : '<i class="fas fa-eye-slash text-sm"></i>';
            });
        }
        
    
        const form = document.querySelector('form');
        const submitBtn = form.querySelector('button[type="submit"]');
        
        form.addEventListener('submit', () => {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';
            submitBtn.disabled = true;
        });
    </script>
</body>
</html>