<?php
session_start();
require_once '../config/mysqli_connect.php';

if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    
    if($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } elseif(strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } else {
        
        $check_query = "SELECT id FROM users WHERE username = '$username' OR email = '$email'";
        $check_result = mysqli_query($conn, $check_query);
        
        if(mysqli_num_rows($check_result) > 0) {
            $error = "Username or email already exists!";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO users (username, email, password, full_name, role, status) 
                           VALUES ('$username', '$email', '$hashed_password', '$full_name', 'admin', 'active')";
            
            if(mysqli_query($conn, $insert_query)) {
                $success = "Registration successful! You can now login.";
                $_POST = array();
            } else {
                $error = "Registration failed: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Admin - Earthen Style</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }
        
        .serif {
            font-family: 'Playfair Display', serif;
        }
        
        body {
            background: #f5f0eb;
        }
        
        .register-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
        }
        
        .input-field {
            transition: all 0.2s ease;
            background: #fafaf9;
            border: 1px solid #e5e5e5;
        }
        
        .input-field:focus {
            outline: none;
            border-color: #A0522D;
            background: white;
            box-shadow: 0 0 0 3px rgba(160, 82, 45, 0.1);
        }
        
        .btn-register {
            background: #A0522D;
            transition: all 0.2s ease;
        }
        
        .btn-register:hover {
            background: #8B4513;
            transform: translateY(-1px);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="register-card p-8">
            <div class="text-center mb-6">
                <div class="text-4xl mb-3">👜</div>
                <h2 class="text-xl font-bold serif text-gray-800">Create Admin Account</h2>
                <p class="text-gray-500 text-sm mt-1">Join Earthen Style team</p>
                <div class="w-12 h-0.5 bg-amber-600 mx-auto mt-3"></div>
            </div>
            
            <?php if($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-2 rounded-lg mb-4 text-sm">
                    <i class="fas fa-exclamation-circle mr-2"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-2 rounded-lg mb-4 text-sm">
                    <i class="fas fa-check-circle mr-2"></i> <?php echo $success; ?>
                    <div class="mt-2">
                        <a href="login.php" class="text-green-700 font-semibold underline">Click here to login →</a>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="space-y-3">
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">Full Name</label>
                    <input type="text" name="full_name" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="Enter your full name"
                           value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">Username</label>
                    <input type="text" name="username" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="Choose a username"
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">Email Address</label>
                    <input type="email" name="email" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="admin@example.com"
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">Password</label>
                    <input type="password" name="password" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="Minimum 6 characters">
                </div>
                
                <div>
                    <label class="block text-gray-700 font-medium mb-1 text-sm">Confirm Password</label>
                    <input type="password" name="confirm_password" required 
                           class="input-field w-full rounded-lg px-4 py-2 text-sm"
                           placeholder="Re-enter your password">
                </div>
                
                <button type="submit" class="btn-register w-full text-white font-medium py-2 rounded-lg transition flex items-center justify-center gap-2">
                    <i class="fas fa-user-plus"></i>
                    Create Account
                </button>
            </form>
            
            <div class="mt-5 text-center">
                <p class="text-sm text-gray-600">
                    Already have an account?
                    <a href="login.php" class="text-amber-600 font-semibold hover:text-amber-700 transition">
                        Sign in here
                    </a>
                </p>
            </div>
        </div>
        
        <p class="text-center text-gray-400 text-xs mt-6">
            © 2026 Earthen Style. All rights reserved.
        </p>
    </div>
</body>
</html>